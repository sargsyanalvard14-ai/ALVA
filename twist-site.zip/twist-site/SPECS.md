# Twist · Projet vibecoding

## Produit
On vend **Twist**, une canette de 330 ml avec **deux goûts** : un côté plat (*still*) et un côté pétillant (*sparkling*). Une bague sur le dessus permet de choisir : à gauche le plat, à droite le pétillant, au centre les deux.

- **Cible** : les 8-30 ans, surtout les étudiants, qui cherchent des boissons originales.
- **Promesse** : une seule canette, deux goûts différents. On choisit son goût, ou on découvre deux saveurs dans la même boisson.
- **Gamme** : 4 duos, 8 saveurs.
  - Mangue × Passion
  - Ananas × Coco
  - Litchi × Framboise
  - Pastèque × Pitaya
- **Prix** (fictifs) :
  - 2,50 € la canette
  - Pack de 6 : 13,90 €
  - Pack de 12 : 26,90 €
  - Pack Découverte : 24,90 € au lieu de 30 €
  - Livraison 3,90 €, offerte dès 20 €
- **Style** : défini dans `charte/charte.md`. Le ton est fun et complice, on tutoie. Le site s'inspire de ciaokombucha.com.

## Qui fait quoi
Équipe d'une seule personne (Alva), qui tient tous les rôles. Chaque zone a été faite dans un prompt et un commit séparés.

| Zone | Fichiers |
|---|---|
| Pilote (socle) | `server.js`, `db/`, `routes/`, `admin/`, `AGENTS.md`, `SPECS.md` |
| Charte | `charte/charte.md`, `charte/variables.css` |
| Communs + compte client | `public/communs/`, `inscription.html`, `connexion.html`, `compte.html`, `js/auth.js`, `css/pages.css` |
| Accueil + élément original | `index.html`, `css/accueil.css`, `js/accueil.js`, `js/accueil-3d.js` |
| Page produit + panier | `produit.html`, `panier.html`, `css/produit.css`, `js/produit.js`, `js/panier.js`, `routes/orders.js` |
| Landing page bundle | `bundle.html`, `css/bundle.css`, `js/bundle.js` |

## Règle commune
Chaque page :
- suit `charte/charte.md` ;
- intègre `communs/header.html` et `communs/footer.html` (copiés avec `npm run communs`) ;
- charge `communs/communs.css` et `communs/communs.js`.

## Avancement

### Obligatoire (must)
- [x] Socle : serveur Express, base SQLite, dossiers, données de test
- [x] Charte graphique tirée de la canette (`charte/`)
- [x] Header, footer et styles communs
- [x] **Accueil** : promesse, visuel, appel à l'action vers le produit
- [x] **Élément original** : canette 3D Three.js qu'on fait tourner et qui change de duo, et roue des saveurs en pop-up
- [x] **Page produit** : visuels, description, prix, variantes (duo + format), bouton « Commander »
- [x] **Landing page bundle** : offre groupée, bénéfices, réassurance (avis, garantie, livraison), FAQ, un seul appel à l'action
- [x] **Inscription + connexion** email / mot de passe (bcrypt), données en base
- [x] **Commande** (paiement simulé) enregistrée en base, prix recalculés côté serveur
- [x] **Back-office** `/admin` : utilisateurs et commandes, accès admin seulement

### Souhaitable (should)
- [x] Panier avec plusieurs produits et quantités
- [x] Page « Mon compte » avec l'historique des commandes
- [x] Changer le statut d'une commande depuis le back-office
- [x] Responsive : site utilisable sur mobile (testé à 375 px)
- [x] Formulaire de contact enregistré en base (visible dans `/admin/messages.html`)
- [x] Élément original interactif et animé
- [x] Connexion Google : le code est prêt, il s'active en remplissant `GOOGLE_CLIENT_ID` et `GOOGLE_CLIENT_SECRET` dans `.env`

### Bonus (could)
- [x] Page mentions légales
- [x] Newsletter enregistrée en base
- [x] Page 404 personnalisée
- [ ] Email de confirmation de commande
- [ ] Thème clair / sombre

## Comptes de test
- **Admin** : identifiants définis dans `.env` (`ADMIN_EMAIL` / `ADMIN_PASSWORD`).
- **Client de démo** : `demo@twist.fr` / `demo1234`. Il a déjà 2 commandes.

## À savoir
- Les avis de la page Pack sont fictifs. C'est indiqué sur la page.
- Produits, prix et allégations sont fictifs (projet étudiant).
