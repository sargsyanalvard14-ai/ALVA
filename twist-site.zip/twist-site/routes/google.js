// Connexion « en un clic » avec Google (optionnelle).
// Activée seulement si GOOGLE_CLIENT_ID et GOOGLE_CLIENT_SECRET sont remplis dans .env.
const express = require('express');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const db = require('../db/database');

const router = express.Router();

passport.use(new GoogleStrategy(
  {
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: process.env.GOOGLE_CALLBACK_URL || 'http://localhost:3000/auth/google/callback'
  },
  (accessToken, refreshToken, profile, done) => {
    const email = profile.emails && profile.emails[0] ? profile.emails[0].value.toLowerCase() : null;
    if (!email) return done(null, false);
    const prenom = (profile.name && profile.name.givenName) || profile.displayName || 'Ami·e';

    // 1. Déjà venu avec Google ? 2. Compte email existant ? on le relie. 3. Sinon on le crée.
    let user = db.prepare('SELECT * FROM users WHERE google_id = ?').get(profile.id);
    if (!user) {
      user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
      if (user) {
        db.prepare('UPDATE users SET google_id = ? WHERE id = ?').run(profile.id, user.id);
      } else {
        const info = db.prepare('INSERT INTO users (prenom, email, google_id) VALUES (?, ?, ?)').run(prenom, email, profile.id);
        user = { id: info.lastInsertRowid };
      }
    }
    done(null, { id: user.id });
  }
));

router.use(passport.initialize());

router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'], session: false }));

router.get('/google/callback',
  passport.authenticate('google', { session: false, failureRedirect: '/connexion.html?erreur=google' }),
  (req, res) => {
    req.session.regenerate(() => {
      req.session.userId = req.user.id;
      req.session.save(() => res.redirect('/compte.html'));
    });
  }
);

module.exports = router;
