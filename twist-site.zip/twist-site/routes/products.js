// API catalogue : produits et formats, lus en base (jamais en dur dans le HTML).
const express = require('express');
const db = require('../db/database');

const router = express.Router();

// GET /api/products → tous les produits (canettes puis pack)
router.get('/products', (req, res) => {
  res.json(db.prepare('SELECT * FROM products ORDER BY ordre').all());
});

// GET /api/products/:id
router.get('/products/:id', (req, res) => {
  const p = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!p) return res.status(404).json({ erreur: 'Produit introuvable.' });
  res.json(p);
});

// GET /api/formats → à l'unité, pack de 6, pack de 12
router.get('/formats', (req, res) => {
  res.json(db.prepare('SELECT * FROM formats ORDER BY nb_canettes').all());
});

module.exports = router;
