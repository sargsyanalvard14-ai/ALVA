// API formulaire de contact et newsletter, enregistrés en base.
const express = require('express');
const db = require('../db/database');
const { EMAIL_REGEX } = require('./guards');

const router = express.Router();

// POST /api/contact { nom, email, message }
router.post('/contact', (req, res) => {
  const nom = String(req.body.nom || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const message = String(req.body.message || '').trim();
  if (nom.length < 1 || nom.length > 80) return res.status(400).json({ erreur: 'Dis-nous ton nom.' });
  if (!EMAIL_REGEX.test(email)) return res.status(400).json({ erreur: 'Cet email n\'a pas l\'air valide.' });
  if (message.length < 5 || message.length > 2000) {
    return res.status(400).json({ erreur: 'Ton message doit faire entre 5 et 2000 caractères.' });
  }
  db.prepare('INSERT INTO messages (nom, email, message) VALUES (?, ?, ?)').run(nom, email, message);
  res.status(201).json({ ok: true });
});

// POST /api/newsletter { email }
router.post('/newsletter', (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  if (!EMAIL_REGEX.test(email)) return res.status(400).json({ erreur: 'Cet email n\'a pas l\'air valide.' });
  db.prepare('INSERT OR IGNORE INTO newsletter (email) VALUES (?)').run(email);
  res.status(201).json({ ok: true });
});

module.exports = router;
