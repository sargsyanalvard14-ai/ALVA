// API back-office : utilisateurs, commandes, messages. Toute route vérifie que la session est admin.
const express = require('express');
const db = require('../db/database');
const { exigeAdmin } = require('./guards');

const router = express.Router();
router.use(exigeAdmin);

const STATUTS = ['payée', 'en préparation', 'expédiée', 'livrée', 'annulée'];

// GET /api/admin/stats
router.get('/stats', (req, res) => {
  res.json({
    utilisateurs: db.prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'client'").get().n,
    commandes: db.prepare('SELECT COUNT(*) AS n FROM orders').get().n,
    a_preparer: db.prepare("SELECT COUNT(*) AS n FROM orders WHERE statut IN ('payée', 'en préparation')").get().n,
    chiffre_cents: db.prepare("SELECT COALESCE(SUM(total_cents), 0) AS s FROM orders WHERE statut != 'annulée'").get().s,
    messages: db.prepare('SELECT COUNT(*) AS n FROM messages').get().n,
    newsletter: db.prepare('SELECT COUNT(*) AS n FROM newsletter').get().n
  });
});

// GET /api/admin/users
router.get('/users', (req, res) => {
  res.json(db.prepare(`
    SELECT u.id, u.prenom, u.email, u.role, u.created_at,
           (u.google_id IS NOT NULL) AS via_google,
           COUNT(o.id) AS nb_commandes,
           COALESCE(SUM(o.total_cents), 0) AS total_cents
    FROM users u LEFT JOIN orders o ON o.user_id = u.id
    GROUP BY u.id ORDER BY u.created_at DESC, u.id DESC
  `).all());
});

// GET /api/admin/orders
router.get('/orders', (req, res) => {
  const commandes = db.prepare(`
    SELECT o.*, u.prenom, u.email FROM orders o JOIN users u ON u.id = o.user_id
    ORDER BY o.created_at DESC, o.id DESC
  `).all();
  const items = db.prepare('SELECT libelle, quantite, prix_unitaire_cents FROM order_items WHERE order_id = ?');
  res.json({ statuts: STATUTS, commandes: commandes.map((c) => ({ ...c, items: items.all(c.id) })) });
});

// PATCH /api/admin/orders/:id { statut }
router.patch('/orders/:id', (req, res) => {
  const statut = String(req.body.statut || '');
  if (!STATUTS.includes(statut)) return res.status(400).json({ erreur: 'Statut inconnu.' });
  const info = db.prepare('UPDATE orders SET statut = ? WHERE id = ?').run(statut, Number(req.params.id));
  if (info.changes === 0) return res.status(404).json({ erreur: 'Commande introuvable.' });
  res.json({ ok: true, statut });
});

// GET /api/admin/messages
router.get('/messages', (req, res) => {
  res.json({
    messages: db.prepare('SELECT * FROM messages ORDER BY created_at DESC, id DESC').all(),
    newsletter: db.prepare('SELECT * FROM newsletter ORDER BY created_at DESC, id DESC').all()
  });
});

module.exports = router;
