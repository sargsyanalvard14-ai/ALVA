// Petits « vigiles » réutilisés par les routes : connecté ? admin ?
const db = require('../db/database');

function utilisateurCourant(req) {
  if (!req.session || !req.session.userId) return null;
  return db.prepare('SELECT id, prenom, email, role FROM users WHERE id = ?').get(req.session.userId) || null;
}

// Pour l'API : renvoie 401 en JSON si personne n'est connecté
function exigeConnexion(req, res, next) {
  const user = utilisateurCourant(req);
  if (!user) return res.status(401).json({ erreur: 'Connecte-toi pour continuer.' });
  req.user = user;
  next();
}

// Pour l'API admin : 403 si l'utilisateur n'est pas admin
function exigeAdmin(req, res, next) {
  const user = utilisateurCourant(req);
  if (!user || user.role !== 'admin') return res.status(403).json({ erreur: 'Accès réservé à l\'admin.' });
  req.user = user;
  next();
}

// Pour les pages HTML de admin/ : redirection vers l'accueil si pas admin
function exigeAdminPage(req, res, next) {
  const user = utilisateurCourant(req);
  if (!user || user.role !== 'admin') return res.redirect('/');
  next();
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

module.exports = { utilisateurCourant, exigeConnexion, exigeAdmin, exigeAdminPage, EMAIL_REGEX };
