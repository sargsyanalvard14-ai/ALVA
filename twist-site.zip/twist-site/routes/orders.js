// API commandes : passer une commande (paiement simulé) et voir les siennes.
// Utilisée par public/panier.html et public/compte.html.
const express = require('express');
const db = require('../db/database');
const { exigeConnexion } = require('./guards');

const router = express.Router();

const FRAIS_PORT = 390;               // 3,90 €
const LIVRAISON_OFFERTE_DES = 2000;   // offerte dès 20 €

// POST /api/orders { items: [{ product_id, format_id, quantite }], adresse }
// Les prix sont TOUJOURS recalculés ici depuis la base : on ne fait pas confiance au navigateur.
router.post('/', exigeConnexion, (req, res) => {
  const items = Array.isArray(req.body.items) ? req.body.items : [];
  const adresse = String(req.body.adresse || '').trim();

  if (items.length === 0 || items.length > 30) {
    return res.status(400).json({ erreur: 'Ton panier est vide.' });
  }
  if (adresse.length < 10 || adresse.length > 300) {
    return res.status(400).json({ erreur: 'Indique une adresse de livraison complète.' });
  }

  const lignes = [];
  for (const it of items) {
    const quantite = Number.parseInt(it.quantite, 10);
    if (!Number.isInteger(quantite) || quantite < 1 || quantite > 99) {
      return res.status(400).json({ erreur: 'Quantité invalide.' });
    }
    const produit = db.prepare('SELECT * FROM products WHERE id = ?').get(String(it.product_id || ''));
    if (!produit) return res.status(400).json({ erreur: 'Un produit du panier n\'existe plus.' });

    if (produit.type === 'pack') {
      lignes.push({ produit, format: null, quantite, prix: produit.prix_cents, libelle: `${produit.nom} — 12 canettes` });
    } else {
      const format = db.prepare('SELECT * FROM formats WHERE id = ?').get(Number(it.format_id));
      if (!format) return res.status(400).json({ erreur: 'Format invalide.' });
      lignes.push({ produit, format, quantite, prix: format.prix_cents, libelle: `${produit.nom} — ${format.label}` });
    }
  }

  const sousTotal = lignes.reduce((s, l) => s + l.prix * l.quantite, 0);
  const port = sousTotal >= LIVRAISON_OFFERTE_DES ? 0 : FRAIS_PORT;
  const total = sousTotal + port;

  const enregistrer = db.transaction(() => {
    const info = db.prepare("INSERT INTO orders (user_id, total_cents, statut, adresse) VALUES (?, ?, 'payée', ?)")
      .run(req.user.id, total, adresse);
    const insert = db.prepare(
      'INSERT INTO order_items (order_id, product_id, format_id, libelle, quantite, prix_unitaire_cents) VALUES (?, ?, ?, ?, ?, ?)'
    );
    for (const l of lignes) {
      insert.run(info.lastInsertRowid, l.produit.id, l.format ? l.format.id : null, l.libelle, l.quantite, l.prix);
    }
    return info.lastInsertRowid;
  });

  const orderId = enregistrer();
  res.status(201).json({ id: orderId, sous_total_cents: sousTotal, port_cents: port, total_cents: total, statut: 'payée' });
});

// GET /api/orders/livraison → règles de livraison (affichées dans le panier)
router.get('/livraison', (req, res) => {
  res.json({ frais_cents: FRAIS_PORT, offerte_des_cents: LIVRAISON_OFFERTE_DES });
});

// GET /api/orders/mine → historique du client connecté
router.get('/mine', exigeConnexion, (req, res) => {
  const commandes = db.prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC, id DESC').all(req.user.id);
  const items = db.prepare('SELECT libelle, quantite, prix_unitaire_cents, product_id FROM order_items WHERE order_id = ?');
  res.json(commandes.map((c) => ({ ...c, items: items.all(c.id) })));
});

module.exports = router;
