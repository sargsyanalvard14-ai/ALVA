// API comptes : inscription, connexion, déconnexion, « qui suis-je ».
// Utilisée par public/inscription.html, connexion.html, compte.html et le header.
const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db/database');
const { utilisateurCourant, EMAIL_REGEX } = require('./guards');

const router = express.Router();

function ouvrirSession(req, user, cb) {
  // On régénère la session à la connexion (évite la fixation de session)
  req.session.regenerate((err) => {
    if (err) return cb(err);
    req.session.userId = user.id;
    req.session.save(cb);
  });
}

// POST /api/auth/register { prenom, email, password }
router.post('/register', (req, res) => {
  const prenom = String(req.body.prenom || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');

  if (prenom.length < 1 || prenom.length > 40) {
    return res.status(400).json({ erreur: 'Ton prénom doit faire entre 1 et 40 caractères.' });
  }
  if (!EMAIL_REGEX.test(email) || email.length > 120) {
    return res.status(400).json({ erreur: 'Cet email n\'a pas l\'air valide.' });
  }
  if (password.length < 8 || password.length > 100) {
    return res.status(400).json({ erreur: 'Le mot de passe doit faire au moins 8 caractères.' });
  }
  if (db.prepare('SELECT id FROM users WHERE email = ?').get(email)) {
    return res.status(409).json({ erreur: 'Un compte existe déjà avec cet email. Connecte-toi !' });
  }

  const hash = bcrypt.hashSync(password, 10);
  const info = db.prepare('INSERT INTO users (prenom, email, password_hash) VALUES (?, ?, ?)').run(prenom, email, hash);
  const user = { id: info.lastInsertRowid, prenom, email, role: 'client' };

  ouvrirSession(req, user, (err) => {
    if (err) return res.status(500).json({ erreur: 'Session impossible, réessaie.' });
    res.status(201).json({ user });
  });
});

// POST /api/auth/login { email, password }
router.post('/login', (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email);

  // Même message que l'email ou le mot de passe soit faux : on ne révèle rien
  if (!row || !row.password_hash || !bcrypt.compareSync(password, row.password_hash)) {
    return res.status(401).json({ erreur: 'Email ou mot de passe incorrect.' });
  }
  const user = { id: row.id, prenom: row.prenom, email: row.email, role: row.role };
  ouvrirSession(req, user, (err) => {
    if (err) return res.status(500).json({ erreur: 'Session impossible, réessaie.' });
    res.json({ user });
  });
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('twist.sid');
    res.json({ ok: true });
  });
});

// GET /api/auth/me → { user } ou { user: null }
router.get('/me', (req, res) => {
  res.json({ user: utilisateurCourant(req) });
});

// GET /api/auth/config → le bouton Google doit-il s'afficher ?
router.get('/config', (req, res) => {
  res.json({ google: Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) });
});

module.exports = router;
