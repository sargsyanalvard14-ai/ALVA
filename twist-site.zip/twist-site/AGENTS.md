# AGENTS.md — Règles du projet Twist

> Lu automatiquement par l'agent (OpenCode, Cursor, Claude Code…) au début de chaque conversation.

## Le projet
Site de vente de **Twist**, une canette avec deux goûts (un côté plat, un côté pétillant).
Lis toujours **SPECS.md** (qui fait quoi, où on en est) et **charte/charte.md** (style et ton) avant de coder.

## Stack (ne pas en changer)
- **Pages** : HTML + CSS + JavaScript vanilla dans `public/`. Pas de framework front, pas de compilation.
- **CSS** : un fichier par page dans `public/css/`. Les styles communs sont dans `public/communs/communs.css`, qui importe `charte/variables.css`.
- **JS** : un fichier par page dans `public/js/`. Les outils communs (`window.Twist` : api, euros, Panier, Auth, toast) sont dans `public/communs/communs.js`.
- **3D** : Three.js via CDN (importmap dans `index.html`), uniquement pour l'élément original de l'accueil.
- **Serveur** : Node.js + Express, un seul `server.js`. Les routes de l'API sont dans `routes/`.
- **Base** : SQLite via better-sqlite3, fichier `data.db`. Le schéma est dans `db/schema.sql`, les données de départ dans `db/seed.js`.
- **Comptes** : express-session + bcryptjs (mots de passe hachés). Google en option via passport-google-oauth20.
- **Back-office** : pages HTML dans `admin/`, servies seulement si la session est admin.

## Règles
1. **Ne modifie que les fichiers demandés.** Si tu dois toucher un autre fichier, dis-le et attends mon accord.
2. **N'installe aucune dépendance** sans me le demander.
3. **Propose un plan avant de coder** (5 lignes max) et attends mon OK.
4. **Utilise les variables de la charte** (`var(--couleur-accent)`, `var(--police-titre)`…). Jamais de code couleur en dur dans les pages.
5. **Header et footer** : ne les modifie pas dans les pages. On les modifie dans `public/communs/` puis on lance `npm run communs`.
6. **Données** : les produits et les prix viennent de l'API (`/api/products`, `/api/formats`), jamais en dur dans le HTML. Les prix d'une commande sont **recalculés côté serveur**.
7. **Sécurité** : aucun secret dans le code. Tout passe par `.env` (jamais commité). On valide toutes les entrées côté serveur. Toute route de `routes/admin.js` vérifie que la session est admin.
8. **Textes de l'interface en français**, en tutoyant, sur le ton de la charte.
9. **Animations** : elles doivent respecter `prefers-reduced-motion`.
10. **À la fin**, donne la liste des fichiers créés ou modifiés et les 3 actions pour tester à la main.

## Lancer le projet
```bash
npm install
cp .env.example .env   # puis remplir les valeurs
npm run dev            # http://localhost:3000
```
