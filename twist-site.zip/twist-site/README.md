# Twist — Une canette. Deux goûts.

Site de vente vibecodé pour **Twist**, la canette à deux compartiments : un côté plat, un côté pétillant.

## Lancer le site

Il faut **Node.js 18 ou plus** ([nodejs.org](https://nodejs.org)). Dans le terminal de VS Code, à la racine du projet :

```bash
npm install            # installe les 7 dépendances (une seule fois)
cp .env.example .env   # si le fichier .env n'existe pas encore, puis remplir les valeurs
npm run dev            # démarre le serveur et le relance à chaque modification
```

Ouvre ensuite **http://localhost:3000**.

Au premier lancement, la base `data.db` est créée et remplie toute seule :
- les produits ;
- le compte admin défini dans `.env` ;
- un client de démo, `demo@twist.fr` / `demo1234`.

## Parcours de démo

1. **Accueil** : fais tourner la canette 3D à la souris et change de duo avec les pastilles. Plus bas :
   - teste la bague dans la section « Le twist » ;
   - ouvre la roue des saveurs (bouton en bas à droite).
2. **La gamme** : choisis un duo, un format et une quantité, puis clique sur **Commander**.
3. **Panier** : connecte-toi ou inscris-toi, entre une adresse, puis clique sur **Payer** (paiement simulé).
4. **Mon compte** : la commande apparaît avec son statut.
5. **Back-office** : connecte-toi en admin, va sur `/admin`, puis change le statut d'une commande.
6. **Le Pack** : la landing page de l'offre groupée.

## Structure

```
twist-site/
├── AGENTS.md          ← règles pour l'agent IA
├── SPECS.md           ← produit, répartition, avancement
├── charte/            ← charte.md (humain) + variables.css (CSS)
├── server.js          ← Express : pages + API + sessions
├── db/                ← schema.sql, database.js, seed.js
├── routes/            ← auth, products, orders, admin, contact, google, guards
├── admin/             ← back-office (servi seulement à l'admin)
├── outils/            ← copier-communs.js (npm run communs)
└── public/
    ├── communs/       ← header.html, footer.html, communs.css, communs.js
    ├── css/  js/  img/
    ├── index.html  produit.html  bundle.html  panier.html
    ├── inscription.html  connexion.html  compte.html
    └── contact.html  mentions-legales.html  404.html
```

## Commandes utiles

| Commande | Effet |
|---|---|
| `npm run dev` | Lance le site avec rechargement automatique |
| `npm run seed` | Remet les produits et les comptes de démo |
| `npm run communs` | Recopie le header et le footer dans toutes les pages |

Pour repartir de zéro : supprime `data.db` puis relance `npm run dev`.

## Connexion Google (optionnelle)

1. Crée un identifiant OAuth sur [console.cloud.google.com](https://console.cloud.google.com/apis/credentials).
2. Ajoute l'URL de redirection `http://localhost:3000/auth/google/callback`.
3. Mets `GOOGLE_CLIENT_ID` et `GOOGLE_CLIENT_SECRET` dans `.env` (jamais dans le code), puis relance le serveur.

Le bouton « Continuer avec Google » apparaît alors tout seul.
