// Serveur Twist : sert les pages, expose l'API JSON, vérifie la session.
require('dotenv').config();
const path = require('path');
const express = require('express');
const session = require('express-session');

const db = require('./db/database');
const seed = require('./db/seed');
const { exigeAdminPage } = require('./routes/guards');

// Premier lancement : on remplit la base si elle est vide
if (db.prepare('SELECT COUNT(*) AS n FROM products').get().n === 0) {
  seed();
  console.log('Base vide : produits, admin et client de démo créés.');
}

const app = express();
const PORT = process.env.PORT || 3000;

if (!process.env.SESSION_SECRET) {
  console.warn('⚠️  SESSION_SECRET manquant dans .env : copie .env.example en .env.');
}

app.use(express.json({ limit: '50kb' }));
app.use(session({
  name: 'twist.sid',
  secret: process.env.SESSION_SECRET || 'dev-uniquement-changer-dans-env',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', maxAge: 1000 * 60 * 60 * 24 * 7 }
}));

// API
app.use('/api/auth', require('./routes/auth'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api', require('./routes/products'));
app.use('/api', require('./routes/contact'));

// Connexion Google, seulement si les clés sont dans .env
if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
  app.use('/auth', require('./routes/google'));
  console.log('Connexion Google activée.');
}

// Back-office : les pages de admin/ ne sont servies qu'à l'admin
app.get('/admin', (req, res) => res.redirect('/admin/orders.html'));
app.use('/admin', exigeAdminPage, express.static(path.join(__dirname, 'admin')));

// Charte (variables.css) et pages publiques
app.use('/charte', express.static(path.join(__dirname, 'charte')));
app.use(express.static(path.join(__dirname, 'public')));

// API inconnue → 404 JSON ; page inconnue → 404 HTML
app.use('/api', (req, res) => res.status(404).json({ erreur: 'Route inconnue.' }));
app.use((req, res) => res.status(404).sendFile(path.join(__dirname, 'public', '404.html')));

app.listen(PORT, () => {
  console.log(`Twist tourne sur http://localhost:${PORT}`);
});
