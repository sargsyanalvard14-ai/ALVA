// Copie public/communs/header.html et footer.html dans toutes les pages de public/.
// Chaque page reste un fichier HTML complet et lisible de haut en bas.
// Usage : npm run communs   (à relancer quand le header ou le footer change)
const fs = require('fs');
const path = require('path');

const dossier = path.join(__dirname, '..', 'public');
const header = fs.readFileSync(path.join(dossier, 'communs', 'header.html'), 'utf8').trim();
const footer = fs.readFileSync(path.join(dossier, 'communs', 'footer.html'), 'utf8').trim();

const remplacer = (html, nom, contenu) => html.replace(
  new RegExp(`<!-- debut:${nom} -->[\\s\\S]*?<!-- fin:${nom} -->`),
  `<!-- debut:${nom} -->\n${contenu}\n<!-- fin:${nom} -->`
);

let n = 0;
for (const fichier of fs.readdirSync(dossier)) {
  if (!fichier.endsWith('.html')) continue;
  const chemin = path.join(dossier, fichier);
  const avant = fs.readFileSync(chemin, 'utf8');
  const apres = remplacer(remplacer(avant, 'header', header), 'footer', footer);
  if (apres !== avant) { fs.writeFileSync(chemin, apres); n++; }
}
console.log(`Header et footer copiés dans ${n} page(s).`);
