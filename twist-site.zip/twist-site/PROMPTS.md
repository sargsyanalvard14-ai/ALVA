# Journal de vibecoding — Twist

Ce fichier garde une trace des prompts importants : ce qu'on a demandé, ce qui a marché, et ce qui a mal tourné. Il sert à préparer la partie « Compréhension » de la démo.

## Les étapes (un prompt et un commit par étape)

1. **Socle** : serveur Express, base SQLite (`db/schema.sql`), dossiers, `AGENTS.md`, `SPECS.md`.
2. **Charte** : `charte/charte.md` et `variables.css`. Les couleurs sont **relevées sur les canettes** : 2 couleurs par duo, le crème du logo, l'aubergine pour le texte.
3. **Communs** : header (bouton Connexion qui devient « Bonjour Prénom »), footer, styles de base.
4. **API** : comptes (bcrypt + session), produits, commandes, back-office, contact.
5. **Accueil** : hero coupé en deux comme la canette, canette 3D, démo de la bague, gamme, roue des saveurs.
6. **Page produit + panier** : duo, format, quantité, Commander, paiement simulé.
7. **Landing bundle** : Pack Découverte, réassurance, avis, FAQ, un seul appel à l'action.
8. **Compte client** : inscription, connexion, historique des commandes.
9. **Back-office** : commandes (changement de statut), utilisateurs, messages.
10. **Tests et corrections** : parcours complet, mobile, sécurité.

## Exemple de prompt (5 blocs)

> **Contexte** : site Twist, voir @SPECS.md et @charte/charte.md. Les produits sont servis par `/api/products`.
> **Objectif** : la page `produit.html`. Le client choisit un duo, un format (unité, 6, 12) et une quantité, puis clique sur « Commander ».
> **Contraintes** : ne touche qu'à `produit.html`, `css/produit.css` et `js/produit.js`. Utilise les variables de la charte et `window.Twist.Panier`. Aucune nouvelle dépendance.
> **Critères** : quand je change de duo, les couleurs, la canette et les fruits changent sans recharger la page. Quand je choisis « Pack de 6 » × 2, le prix affiché est 27,80 €. Quand je clique sur « Commander », j'arrive sur le panier avec le bon article.
> **Format** : plan d'abord, puis la liste des fichiers modifiés et 3 actions pour tester.

## Ce qui a mal tourné, et comment on l'a rattrapé

### 1. La canette géante
**Ce qu'on a vu** : sur l'accueil, la canette 2D prenait tout l'écran au lieu de 92 % de sa zone.

**Pourquoi** : une hauteur en `%` sur une image placée dans une grille CSS n'est pas toujours calculée. Le navigateur prenait alors la taille réelle de l'image (1368 px).

**Correction** : on a placé l'image en `position: absolute`, dans un parent dont la hauteur est connue. On a corrigé de la même façon la page produit et les cartes de la gamme.

### 2. La correction qui ne marchait pas
**Ce qu'on a vu** : dans les cartes de la gamme, la canette restait énorme alors que la correction était faite.

**Pourquoi** : un vieux `position: relative` était resté plus bas dans la même règle CSS et annulait le `position: absolute`.

**Leçon** : ne pas croire le « c'est corrigé ». On relit le diff et on reteste dans le navigateur.

### 3. Le site qui déborde sur mobile
**Ce qu'on a vu** : sur un écran de 375 px, la page défilait sur le côté (395 px de large).

**Pourquoi** : le header (logo, panier, bouton Connexion et bouton menu) était trop large.

**Correction** : un logo plus petit et des espacements réduits sous 820 px. On a revérifié les 10 pages à 375 px.

### 4. Le bouton « roue » sur les boutons du hero
**Ce qu'on a vu** : le bouton flottant de la roue cachait le bouton « Le Pack Découverte ».

**Correction** : le bouton n'apparaît qu'une fois le hero dépassé.

## Sécurité : ce qui a été relu à la main
- **Mots de passe** : hachés avec bcrypt, jamais renvoyés au navigateur. Le message d'erreur est le même que l'email ou le mot de passe soit faux.
- **Session** : régénérée à la connexion, cookie `httpOnly` et `sameSite`.
- **Prix** : recalculés **côté serveur** à partir de la base. Un prix modifié dans le navigateur est ignoré.
- **Admin** : les pages de `admin/` redirigent vers l'accueil si on n'est pas admin, et chaque route `/api/admin` revérifie la session.
- **Secrets** : `.env` est dans `.gitignore`, et le dépôt ne contient que `.env.example`.
- **Affichage** : tout texte tapé par un utilisateur est échappé avant d'être affiché (fonction `echapper`).
