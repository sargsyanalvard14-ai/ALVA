// Données de départ : produits, formats, compte admin et un client de démo.
// Lancé automatiquement par server.js si la table products est vide,
// ou à la main avec : npm run seed
require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./database');

const produits = [
  {
    id: 'mangue-passion', type: 'canette', nom: 'Mangue × Passion', ordre: 1,
    plat_nom: 'Mangue', plat_label: 'STILL MANGO', plat_couleur: '#ECA326', plat_fruit: 'mangue',
    plat_notes: 'Mangue bien mûre, toute douce, qui fond en bouche. Le côté câlin du duo.',
    petillant_nom: 'Fruit de la passion', petillant_label: 'SPARKLING PASSION FRUIT', petillant_couleur: '#DC524C', petillant_fruit: 'passion',
    petillant_notes: 'Passion acidulée et bulles vives : ça pique juste ce qu\'il faut.',
    accroche: 'Le soleil d\'un côté, le peps de l\'autre.',
    description: 'Notre duo star. Tourne à gauche pour une mangue plate et gourmande, à droite pour un fruit de la passion qui pétille. Au milieu ? Un cocktail tropical sans alcool qui sent les vacances.',
    image: '/img/canettes/mangue-passion.webp', prix_cents: 250
  },
  {
    id: 'ananas-coco', type: 'canette', nom: 'Ananas × Coco', ordre: 2,
    plat_nom: 'Ananas', plat_label: 'STILL PINEAPPLE', plat_couleur: '#EAB52F', plat_fruit: 'ananas',
    plat_notes: 'Ananas juteux, sucré-acidulé, servi bien frais.',
    petillant_nom: 'Coco', petillant_label: 'SPARKLING COCONUT', petillant_couleur: '#DDC7B2', petillant_fruit: 'coco',
    petillant_notes: 'Eau de coco légère et fines bulles : douceur crémeuse, zéro lourdeur.',
    accroche: 'Une piña colada, mais en mieux élevée.',
    description: 'Le duo plage. Un ananas plat et ensoleillé d\'un côté, une coco pétillante et légère de l\'autre. Mélange les deux et ferme les yeux : tu entends les vagues.',
    image: '/img/canettes/ananas-coco.webp', prix_cents: 250
  },
  {
    id: 'litchi-framboise', type: 'canette', nom: 'Litchi × Framboise', ordre: 3,
    plat_nom: 'Litchi', plat_label: 'STILL LYCHEE', plat_couleur: '#E9908F', plat_fruit: 'litchi',
    plat_notes: 'Litchi floral et délicat, avec une petite note de rose.',
    petillant_nom: 'Framboise', petillant_label: 'SPARKLING RASPBERRY', petillant_couleur: '#C20E2D', petillant_fruit: 'framboise',
    petillant_notes: 'Framboise intense et pétillante, franche et fruitée.',
    accroche: 'Douceur florale contre framboise qui claque.',
    description: 'Le duo le plus rose de la bande. Un litchi plat, tout en finesse, et une framboise pétillante qui réveille. Ensemble ? Un sorbet qui se boit.',
    image: '/img/canettes/litchi-framboise.webp', prix_cents: 250
  },
  {
    id: 'pasteque-pitaya', type: 'canette', nom: 'Pastèque × Pitaya', ordre: 4,
    plat_nom: 'Pastèque & pitaya', plat_label: 'STILL WATERMELON DRAGON FRUIT', plat_couleur: '#F97064', plat_fruit: 'pasteque',
    plat_notes: 'Pastèque rafraîchissante relevée d\'une touche de pitaya.',
    petillant_nom: 'Pitaya', petillant_label: 'SPARKLING DRAGON FRUIT', petillant_couleur: '#D00B54', petillant_fruit: 'pitaya',
    petillant_notes: 'Fruit du dragon exotique, légèrement sucré, avec de belles bulles.',
    accroche: 'Le plus désaltérant de la gamme. Et le plus flashy.',
    description: 'Le duo qui désaltère. Une pastèque plate, fraîche comme une tranche sortie du frigo, face à une pitaya pétillante et exotique. Parfait après le sport ou en terrasse.',
    image: '/img/canettes/pasteque-pitaya.webp', prix_cents: 250
  },
  {
    id: 'pack-decouverte', type: 'pack', nom: 'Le Pack Découverte', ordre: 5,
    accroche: 'Les 8 saveurs, 12 canettes, zéro dilemme.',
    description: '3 canettes de chaque duo : Mangue × Passion, Ananas × Coco, Litchi × Framboise et Pastèque × Pitaya. Livraison offerte.',
    image: '/img/canettes/mangue-passion.webp', prix_cents: 2490, prix_barre_cents: 3000
  }
];

const formats = [
  { id: 1, label: 'À l\'unité', nb_canettes: 1, prix_cents: 250 },
  { id: 2, label: 'Pack de 6', nb_canettes: 6, prix_cents: 1390 },
  { id: 3, label: 'Pack de 12', nb_canettes: 12, prix_cents: 2690 }
];

function seed() {
  const insertProduit = db.prepare(`
    INSERT OR REPLACE INTO products
      (id, type, nom, plat_nom, plat_label, plat_couleur, plat_fruit, plat_notes,
       petillant_nom, petillant_label, petillant_couleur, petillant_fruit, petillant_notes,
       accroche, description, image, prix_cents, prix_barre_cents, ordre)
    VALUES
      (@id, @type, @nom, @plat_nom, @plat_label, @plat_couleur, @plat_fruit, @plat_notes,
       @petillant_nom, @petillant_label, @petillant_couleur, @petillant_fruit, @petillant_notes,
       @accroche, @description, @image, @prix_cents, @prix_barre_cents, @ordre)
  `);
  const insertFormat = db.prepare(
    'INSERT OR REPLACE INTO formats (id, label, nb_canettes, prix_cents) VALUES (@id, @label, @nb_canettes, @prix_cents)'
  );

  const vide = {
    plat_nom: null, plat_label: null, plat_couleur: null, plat_fruit: null, plat_notes: null,
    petillant_nom: null, petillant_label: null, petillant_couleur: null, petillant_fruit: null,
    petillant_notes: null, prix_barre_cents: null
  };

  const tout = db.transaction(() => {
    for (const p of produits) insertProduit.run({ ...vide, ...p });
    for (const f of formats) insertFormat.run(f);

    // Compte admin (identifiants dans .env)
    const adminEmail = (process.env.ADMIN_EMAIL || 'admin@twist.fr').toLowerCase();
    const adminPass = process.env.ADMIN_PASSWORD || 'change-moi';
    const existe = db.prepare('SELECT id FROM users WHERE email = ?').get(adminEmail);
    if (!existe) {
      db.prepare('INSERT INTO users (prenom, email, password_hash, role) VALUES (?, ?, ?, ?)')
        .run(process.env.ADMIN_PRENOM || 'Admin', adminEmail, bcrypt.hashSync(adminPass, 10), 'admin');
    }

    // Client de démo avec deux commandes, pour que le back-office ne soit pas vide
    const demoEmail = 'demo@twist.fr';
    let demo = db.prepare('SELECT id FROM users WHERE email = ?').get(demoEmail);
    if (!demo) {
      const info = db.prepare('INSERT INTO users (prenom, email, password_hash) VALUES (?, ?, ?)')
        .run('Léa', demoEmail, bcrypt.hashSync('demo1234', 10));
      demo = { id: info.lastInsertRowid };
      const cmd1 = db.prepare("INSERT INTO orders (user_id, total_cents, statut, adresse, created_at) VALUES (?, ?, 'livrée', ?, datetime('now', '-6 days'))")
        .run(demo.id, 1780, '12 rue des Bulles, 75011 Paris'); // 13,90 € + 3,90 € de livraison
      db.prepare('INSERT INTO order_items (order_id, product_id, format_id, libelle, quantite, prix_unitaire_cents) VALUES (?, ?, ?, ?, ?, ?)')
        .run(cmd1.lastInsertRowid, 'mangue-passion', 2, 'Mangue × Passion — Pack de 6', 1, 1390);
      const cmd2 = db.prepare("INSERT INTO orders (user_id, total_cents, statut, adresse) VALUES (?, ?, 'en préparation', ?)")
        .run(demo.id, 2490, '12 rue des Bulles, 75011 Paris');
      db.prepare('INSERT INTO order_items (order_id, product_id, format_id, libelle, quantite, prix_unitaire_cents) VALUES (?, ?, NULL, ?, ?, ?)')
        .run(cmd2.lastInsertRowid, 'pack-decouverte', 'Le Pack Découverte — 12 canettes', 1, 2490);
    }
  });
  tout();
}

module.exports = seed;

// Lancement direct : node db/seed.js
if (require.main === module) {
  seed();
  console.log('Base remplie : produits, formats, admin et client de démo.');
}
