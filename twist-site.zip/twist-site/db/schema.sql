-- Schéma de la base Twist (SQLite). Lu au démarrage par db/database.js.
-- Les prix sont en centimes (entiers) pour éviter les erreurs d'arrondi.

CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  prenom        TEXT    NOT NULL,
  email         TEXT    NOT NULL UNIQUE,
  password_hash TEXT,                -- NULL si le compte vient de Google
  google_id     TEXT    UNIQUE,
  role          TEXT    NOT NULL DEFAULT 'client' CHECK (role IN ('client', 'admin')),
  created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS products (
  id                TEXT    PRIMARY KEY,          -- ex. 'mangue-passion'
  type              TEXT    NOT NULL CHECK (type IN ('canette', 'pack')),
  nom               TEXT    NOT NULL,             -- ex. 'Mangue × Passion'
  plat_nom          TEXT,                         -- côté plat (still)
  plat_label        TEXT,                         -- étiquette canette : 'STILL MANGO'
  plat_couleur      TEXT,
  plat_fruit        TEXT,                         -- nom du fichier fruit
  plat_notes        TEXT,
  petillant_nom     TEXT,                         -- côté pétillant (sparkling)
  petillant_label   TEXT,
  petillant_couleur TEXT,
  petillant_fruit   TEXT,
  petillant_notes   TEXT,
  accroche          TEXT    NOT NULL,
  description       TEXT    NOT NULL,
  image             TEXT    NOT NULL,
  prix_cents        INTEGER NOT NULL CHECK (prix_cents > 0),
  prix_barre_cents  INTEGER,
  ordre             INTEGER NOT NULL DEFAULT 0
);

-- Formats de vente des canettes (à l'unité, pack de 6, pack de 12)
CREATE TABLE IF NOT EXISTS formats (
  id           INTEGER PRIMARY KEY,
  label        TEXT    NOT NULL,
  nb_canettes  INTEGER NOT NULL,
  prix_cents   INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS orders (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id),
  total_cents INTEGER NOT NULL,
  statut      TEXT    NOT NULL DEFAULT 'payée'
              CHECK (statut IN ('payée', 'en préparation', 'expédiée', 'livrée', 'annulée')),
  adresse     TEXT    NOT NULL,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS order_items (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id            INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id          TEXT    NOT NULL REFERENCES products(id),
  format_id           INTEGER REFERENCES formats(id),
  libelle             TEXT    NOT NULL,
  quantite            INTEGER NOT NULL CHECK (quantite > 0),
  prix_unitaire_cents INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  nom        TEXT NOT NULL,
  email      TEXT NOT NULL,
  message    TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS newsletter (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  email      TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
