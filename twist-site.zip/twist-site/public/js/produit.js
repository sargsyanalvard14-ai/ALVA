// Page produit : charge le duo (?id=...), gère duo / format / quantité, et le bouton « Commander ».
(function () {
  'use strict';
  const { api, euros, echapper, Panier, toast } = window.Twist;

  const TEXTE_CREME = ['mangue-passion', 'litchi-framboise', 'pasteque-pitaya'];
  let duos = [];
  let formats = [];
  let duo = null;
  let formatId = 1;

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);

  document.addEventListener('DOMContentLoaded', async () => {
    try {
      const [produits, f] = await Promise.all([api('/api/products'), api('/api/formats')]);
      duos = produits.filter((p) => p.type === 'canette');
      formats = f;
    } catch (e) {
      $('[data-nom]').textContent = 'Oups, la gamme ne charge pas.';
      $('[data-accroche]').textContent = 'Vérifie que le serveur est bien lancé (npm run dev).';
      return;
    }

    const id = new URLSearchParams(location.search).get('id');
    if (id === 'pack-decouverte') { location.replace('/bundle.html'); return; }
    construireFormats();
    construireDuos();
    afficher(duos.find((d) => d.id === id) || duos[0], false);
    brancherFormulaire();
  });

  function construireDuos() {
    const zone = $('[data-duos]');
    zone.setAttribute('role', 'radiogroup');
    zone.setAttribute('aria-label', 'Choisis ton duo');
    zone.innerHTML = duos.map((d) => `
      <button type="button" class="duo-option" role="radio" aria-checked="false" data-duo="${d.id}">
        <span class="pastille-mini" style="--a:${d.plat_couleur};--b:${d.petillant_couleur}" aria-hidden="true"></span>
        ${echapper(d.nom)}
      </button>`).join('');
    zone.addEventListener('click', (e) => {
      const b = e.target.closest('[data-duo]');
      if (!b) return;
      const d = duos.find((x) => x.id === b.dataset.duo);
      if (d !== duo) {
        afficher(d, true);
        history.replaceState(null, '', `?id=${d.id}`);
      }
    });
  }

  function construireFormats() {
    const unite = formats.find((f) => f.nb_canettes === 1);
    $('[data-formats]').innerHTML = formats.map((f) => {
      const remise = unite ? Math.round((1 - f.prix_cents / (unite.prix_cents * f.nb_canettes)) * 100) : 0;
      return `
        <div class="format-option">
          <input type="radio" name="format" id="format-${f.id}" value="${f.id}" ${f.id === formatId ? 'checked' : ''}>
          <label for="format-${f.id}">
            <strong>${echapper(f.label)}</strong>
            <span>${euros(f.prix_cents)}</span>
          </label>
          ${remise > 0 ? `<span class="remise">−${remise} %</span>` : ''}
        </div>`;
    }).join('');
    $('[data-formats]').addEventListener('change', (e) => {
      formatId = Number(e.target.value);
      majPrix();
    });
  }

  function afficher(d, anime) {
    duo = d;
    const main = $('[data-produit]');
    main.style.setProperty('--c-plat', d.plat_couleur);
    main.style.setProperty('--c-petillant', d.petillant_couleur);
    main.dataset.textePetillant = TEXTE_CREME.includes(d.id) ? 'creme' : 'sombre';

    document.title = `${d.nom} — Twist`;
    $('[data-fil-nom]').textContent = d.nom;
    $('[data-labels]').textContent = `${d.plat_label} · ${d.petillant_label}`;
    $('[data-nom]').textContent = d.nom;
    $('[data-accroche]').textContent = d.accroche;
    $('[data-description]').textContent = d.description;
    $('[data-plat-nom]').textContent = d.plat_nom;
    $('[data-plat-notes]').textContent = d.plat_notes;
    $('[data-petillant-nom]').textContent = d.petillant_nom;
    $('[data-petillant-notes]').textContent = d.petillant_notes;
    $('[data-cote-plat]').textContent = `Plat · ${d.plat_nom}`;
    $('[data-cote-petillant]').textContent = `Pétillant · ${d.petillant_nom}`;

    // Canette : petite rotation de sortie puis entrée
    const can = $('[data-canette]');
    const changer = () => {
      can.src = d.image;
      can.alt = `Canette Twist ${d.nom}`;
      $$('[data-fruit-plat]').forEach((img) => { img.src = `/img/fruits/${d.plat_fruit}.png`; });
      $$('[data-fruit-petillant]').forEach((img) => { img.src = `/img/fruits/${d.petillant_fruit}.png`; });
      can.classList.remove('change');
    };
    if (anime) { can.classList.add('change'); setTimeout(changer, 250); } else changer();

    $$('[data-duo]').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.duo === d.id)));

    $('[data-autres]').innerHTML = duos.filter((x) => x.id !== d.id).map((x) => `
      <a class="mini-duo" href="/produit.html?id=${x.id}" style="--a:${x.plat_couleur};--b:${x.petillant_couleur}">
        <img src="${x.image}" alt="" loading="lazy" width="460" height="1368">
        <span>${echapper(x.nom)}</span>
      </a>`).join('');

    majPrix();
  }

  function quantite() {
    const n = Number.parseInt($('[data-quantite]').value, 10);
    return Number.isInteger(n) ? Math.min(99, Math.max(1, n)) : 1;
  }

  function majPrix() {
    const f = formats.find((x) => x.id === formatId);
    if (!f) return;
    const q = quantite();
    $('[data-prix]').textContent = euros(f.prix_cents * q);
    $('[data-prix-unite]').textContent = f.nb_canettes > 1
      ? `soit ${euros(Math.round(f.prix_cents / f.nb_canettes))} la canette`
      : (q > 1 ? `${q} canettes` : 'la canette');
  }

  function brancherFormulaire() {
    const champ = $('[data-quantite]');
    $('[data-moins]').addEventListener('click', () => { champ.value = Math.max(1, quantite() - 1); majPrix(); });
    $('[data-plus]').addEventListener('click', () => { champ.value = Math.min(99, quantite() + 1); majPrix(); });
    champ.addEventListener('input', majPrix);
    champ.addEventListener('blur', () => { champ.value = quantite(); majPrix(); });

    const ajouter = () => Panier.ajouter({ product_id: duo.id, format_id: formatId, quantite: quantite() });

    // « Commander » : ajoute au panier puis va au panier pour payer (paiement simulé)
    $('[data-form]').addEventListener('submit', (e) => {
      e.preventDefault();
      ajouter();
      location.href = '/panier.html';
    });
    $('[data-ajouter]').addEventListener('click', () => {
      ajouter();
      toast(`${echapper(duo.nom)} ajouté au panier ! <a href="/panier.html">Voir le panier</a>`);
    });
  }
})();
