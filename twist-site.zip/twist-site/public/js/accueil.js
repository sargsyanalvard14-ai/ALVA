// Accueil Twist : sélecteur de duo du hero, bandeau, démo du twist, gamme, texte qui glisse,
// newsletter et roue des saveurs. La canette 3D est dans js/accueil-3d.js.
(function () {
  'use strict';
  const { api, euros, echapper } = window.Twist;

  // Couleur du texte lisible sur chaque côté pétillant (le coco est clair)
  const TEXTE_PETILLANT = { 'ananas-coco': 'var(--couleur-texte)' };

  let duos = [];
  let duoCourant = null;

  document.addEventListener('DOMContentLoaded', async () => {
    initTwistDemo();
    initGlisse();
    initNewsletter();

    try {
      const produits = await api('/api/products');
      duos = produits.filter((p) => p.type === 'canette');
    } catch (e) {
      document.querySelector('[data-gamme]').innerHTML = '<p>Impossible de charger la gamme. Le serveur est-il lancé ?</p>';
      return;
    }
    construireSelecteur();
    construireBandeau();
    construireGamme();
    initRoue();
    choisirDuo(duos[0], false);
  });

  // ---------- HERO ----------
  function construireSelecteur() {
    const zone = document.querySelector('[data-selecteur]');
    zone.innerHTML = duos.map((d) => `
      <button type="button" class="pastille" role="radio" aria-checked="false" data-duo="${d.id}"
        style="--a:${d.plat_couleur};--b:${d.petillant_couleur}" aria-label="${echapper(d.nom)}" title="${echapper(d.nom)}"></button>
    `).join('');
    zone.addEventListener('click', (e) => {
      const b = e.target.closest('[data-duo]');
      if (b) choisirDuo(duos.find((d) => d.id === b.dataset.duo), true);
    });
    // Flèches du clavier dans le groupe
    zone.addEventListener('keydown', (e) => {
      if (!['ArrowLeft', 'ArrowRight'].includes(e.key)) return;
      const i = duos.indexOf(duoCourant);
      const j = (i + (e.key === 'ArrowRight' ? 1 : -1) + duos.length) % duos.length;
      choisirDuo(duos[j], true);
      zone.querySelector(`[data-duo="${duos[j].id}"]`).focus();
    });
  }

  function choisirDuo(duo, anime) {
    if (!duo || duo === duoCourant) return;
    duoCourant = duo;
    const hero = document.querySelector('[data-hero]');
    hero.style.setProperty('--c-plat', duo.plat_couleur);
    hero.style.setProperty('--c-petillant', duo.petillant_couleur);
    hero.style.setProperty('--t-petillant', TEXTE_PETILLANT[duo.id] || 'var(--couleur-creme)');

    document.querySelectorAll('[data-duo]').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.duo === duo.id)));
    document.querySelector('[data-hero-label-plat]').textContent = duo.plat_label;
    document.querySelector('[data-hero-label-petillant]').textContent = duo.petillant_label;
    document.querySelector('[data-hero-cta]').href = `/produit.html?id=${duo.id}`;

    const img2d = document.querySelector('[data-canette-2d]');
    img2d.src = duo.image;
    img2d.alt = `Canette Twist ${duo.nom}`;

    placerFruits(duo, anime);

    // Le verre de la démo prend aussi les couleurs du duo
    const verre = document.querySelector('[data-verre]');
    verre.style.setProperty('--c-plat', duo.plat_couleur);
    verre.style.setProperty('--c-petillant', duo.petillant_couleur);

    // Prévient la canette 3D
    window.TwistDuoCourant = duo;
    window.dispatchEvent(new CustomEvent('twist:duo', { detail: { duo, anime } }));
  }

  // Positions des fruits autour de la canette (en % de la scène)
  const POSITIONS = [
    { cote: 'plat', x: 2, y: 8, rot: -18, d: 6 },
    { cote: 'plat', x: -4, y: 62, rot: 14, d: 7 },
    { cote: 'petillant', x: 84, y: 14, rot: 16, d: 6.5 },
    { cote: 'petillant', x: 88, y: 66, rot: -12, d: 5.5 }
  ];

  function placerFruits(duo, anime) {
    const zone = document.querySelector('[data-hero-fruits]');
    const anciens = [...zone.children];
    anciens.forEach((img) => { img.classList.add('sort'); setTimeout(() => img.remove(), 400); });
    POSITIONS.forEach((p, i) => {
      const img = document.createElement('img');
      img.src = `/img/fruits/${p.cote === 'plat' ? duo.plat_fruit : duo.petillant_fruit}.png`;
      img.alt = '';
      img.className = 'fruit-flottant sort';
      img.style.left = `${p.x}%`;
      img.style.top = `${p.y}%`;
      img.style.setProperty('--rot', `${p.rot}deg`);
      img.style.setProperty('--d', `${p.d}s`);
      img.style.setProperty('--r', `${-i * 1.3}s`);
      zone.appendChild(img);
      setTimeout(() => img.classList.remove('sort'), anime ? 250 + i * 90 : 50 + i * 90);
    });
  }

  // ---------- BANDEAU DÉFILANT ----------
  function construireBandeau() {
    const mots = duos.flatMap((d) => [d.plat_label, d.petillant_label]);
    const html = mots.map((m) => `<span>${echapper(m)}</span><span class="etoile">✦</span>`).join('');
    document.querySelector('[data-bandeau]').innerHTML = html + html; // deux fois pour une boucle parfaite
  }

  // ---------- DÉMO DU TWIST ----------
  const EXPLICATIONS = {
    plat: 'Bague à gauche : seul le compartiment plat s\'ouvre. Doux, fruité, sans bulles.',
    mix: 'Bague au centre : les deux saveurs se rencontrent. Le meilleur des deux mondes.',
    petillant: 'Bague à droite : place au pétillant. Des bulles vives qui réveillent.'
  };
  const ANGLES = { plat: -55, mix: 0, petillant: 55 };

  function initTwistDemo() {
    const boutons = document.querySelectorAll('[data-mode]');
    const rotor = document.querySelector('.bague-rotor');
    const verre = document.querySelector('[data-verre]');
    const texte = document.querySelector('[data-twist-explication]');
    const choisir = (mode) => {
      boutons.forEach((b) => b.setAttribute('aria-checked', String(b.dataset.mode === mode)));
      rotor.style.transform = `rotate(${ANGLES[mode]}deg)`;
      verre.dataset.mode = mode;
      texte.textContent = EXPLICATIONS[mode];
    };
    boutons.forEach((b) => b.addEventListener('click', () => choisir(b.dataset.mode)));
    choisir('mix');
  }

  // ---------- GAMME ----------
  function construireGamme() {
    const grille = document.querySelector('[data-gamme]');
    grille.innerHTML = duos.map((d, i) => `
      <a class="carte-duo" href="/produit.html?id=${d.id}" data-reveal style="--delai:${i * 0.08}s;--a:${d.plat_couleur};--b:${d.petillant_couleur}" data-tilt>
        <div class="carte-duo-visuel">
          <img class="fruit fruit-a" src="/img/fruits/${d.plat_fruit}.png" alt="">
          <img class="canette" src="${d.image}" alt="Canette ${echapper(d.nom)}" loading="lazy" width="460" height="1368">
          <img class="fruit fruit-b" src="/img/fruits/${d.petillant_fruit}.png" alt="">
        </div>
        <div class="carte-duo-infos">
          <p class="etiquette">${echapper(d.plat_label)} · ${echapper(d.petillant_label)}</p>
          <h3>${echapper(d.nom)}</h3>
          <p>${echapper(d.accroche)}</p>
          <p class="prix">Dès ${euros(d.prix_cents)} <span class="voir">Voir →</span></p>
        </div>
      </a>
    `).join('');
    window.Twist.observerApparitions(grille);

    // Légère inclinaison 3D qui suit la souris
    grille.querySelectorAll('[data-tilt]').forEach((carte) => {
      carte.addEventListener('pointermove', (e) => {
        if (e.pointerType !== 'mouse') return;
        const r = carte.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - 0.5;
        const y = (e.clientY - r.top) / r.height - 0.5;
        carte.style.transform = `perspective(800px) rotateY(${x * 10}deg) rotateX(${-y * 10}deg) translateY(-6px)`;
      });
      carte.addEventListener('pointerleave', () => { carte.style.transform = ''; });
    });
  }

  // ---------- TEXTE QUI GLISSE AU SCROLL ----------
  function initGlisse() {
    const lignes = document.querySelectorAll('[data-glisse]');
    if (!lignes.length || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    let tick = false;
    const maj = () => {
      lignes.forEach((l) => {
        const r = l.getBoundingClientRect();
        const progression = (window.innerHeight - r.top) / (window.innerHeight + r.height);
        const sens = Number(l.dataset.glisse);
        l.style.transform = `translateX(${sens * (progression * -40 + 10)}%)`;
      });
      tick = false;
    };
    window.addEventListener('scroll', () => { if (!tick) { requestAnimationFrame(maj); tick = true; } }, { passive: true });
    maj();
  }

  // ---------- NEWSLETTER ----------
  function initNewsletter() {
    const form = document.querySelector('[data-newsletter]');
    const msg = document.querySelector('[data-newsletter-message]');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      msg.className = 'message-form';
      try {
        await api('/api/newsletter', { method: 'POST', body: { email: form.email.value } });
        msg.textContent = 'Bienvenue dans la Twist Team ! On t\'écrit très vite.';
        msg.classList.add('succes');
        form.reset();
      } catch (err) {
        msg.textContent = err.message;
        msg.classList.add('erreur');
      }
    });
  }

  // ---------- ROUE DES SAVEURS ----------
  function initRoue() {
    const dialog = document.querySelector('[data-roue]');
    const svg = document.querySelector('[data-roue-svg]');
    const lancer = document.querySelector('[data-roue-lancer]');
    const resultat = document.querySelector('[data-roue-resultat]');
    if (!dialog || typeof dialog.showModal !== 'function') {
      document.querySelector('[data-roue-ouvrir]').hidden = true;
      return;
    }

    // 8 parts : chaque duo apparaît deux fois (côté plat, côté pétillant)
    const parts = [];
    duos.forEach((d) => parts.push({ duo: d, couleur: d.plat_couleur, fruit: d.plat_fruit }));
    duos.forEach((d) => parts.push({ duo: d, couleur: d.petillant_couleur, fruit: d.petillant_fruit }));
    // On alterne pour que deux parts voisines n'aient pas le même duo
    const ordre = [0, 5, 2, 7, 4, 1, 6, 3].map((i) => parts[i]);
    const angle = 360 / ordre.length;
    const R = 100;
    svg.innerHTML = ordre.map((p, i) => {
      const a1 = (i * angle - 90) * Math.PI / 180;
      const a2 = ((i + 1) * angle - 90) * Math.PI / 180;
      const mid = ((i + 0.5) * angle - 90) * Math.PI / 180;
      const x1 = R * Math.cos(a1), y1 = R * Math.sin(a1);
      const x2 = R * Math.cos(a2), y2 = R * Math.sin(a2);
      const fx = 66 * Math.cos(mid), fy = 66 * Math.sin(mid);
      return `<path d="M0 0 L${x1.toFixed(2)} ${y1.toFixed(2)} A${R} ${R} 0 0 1 ${x2.toFixed(2)} ${y2.toFixed(2)} Z" fill="${p.couleur}" stroke="#2B0A14" stroke-width="2.5"/>
        <image href="/img/fruits/${p.fruit}.png" x="${(fx - 15).toFixed(1)}" y="${(fy - 20).toFixed(1)}" width="30" height="40"
          transform="rotate(${(i + 0.5) * angle} ${fx.toFixed(1)} ${fy.toFixed(1)})"/>`;
    }).join('') + '<circle r="100" fill="none" stroke="#2B0A14" stroke-width="4"/>';

    let rotation = 0;
    lancer.addEventListener('click', () => {
      lancer.disabled = true;
      resultat.textContent = 'Ça tourne…';
      const index = Math.floor(Math.random() * ordre.length);
      // On veut que le milieu de la part gagnante finisse sous le pointeur (en haut)
      const cible = 360 - (index + 0.5) * angle;
      rotation += 360 * 5 + ((cible - (rotation % 360)) + 360) % 360;
      svg.style.transform = `rotate(${rotation}deg)`;
      setTimeout(() => {
        const d = ordre[index].duo;
        resultat.innerHTML = `Aujourd'hui, ce sera <strong>${echapper(d.nom)}</strong> !<br>
          <a class="btn" href="/produit.html?id=${d.id}">Voir ce duo <span class="fleche" aria-hidden="true">→</span></a>`;
        lancer.disabled = false;
        lancer.textContent = 'Encore !';
        choisirDuo(d, true);
      }, 4300);
    });

    // Le bouton de la roue apparaît une fois le hero dépassé (pour ne pas cacher ses boutons)
    const declencheur = document.querySelector('[data-roue-ouvrir]');
    const majDeclencheur = () => declencheur.classList.toggle('est-visible', window.scrollY > window.innerHeight * 0.6);
    window.addEventListener('scroll', majDeclencheur, { passive: true });
    majDeclencheur();

    const ouvrir = () => { if (!dialog.open) dialog.showModal(); };
    document.querySelector('[data-roue-ouvrir]').addEventListener('click', ouvrir);
    document.querySelector('[data-roue-fermer]').addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', (e) => { if (e.target === dialog) dialog.close(); });

    // Pop-up automatique une seule fois, après 12 secondes sur la page
    let dejaVue = false;
    try { dejaVue = localStorage.getItem('twist-roue-vue') === '1'; } catch (e) { /* ignore */ }
    if (!dejaVue) {
      setTimeout(() => {
        if (document.visibilityState === 'visible' && !document.querySelector('dialog[open]')) {
          ouvrir();
          try { localStorage.setItem('twist-roue-vue', '1'); } catch (e) { /* ignore */ }
        }
      }, 12000);
    }
  }
})();
