// Élément original n°1 : la canette Twist en 3D (Three.js via CDN).
// La texture est dessinée dans un <canvas> à partir des couleurs, des fruits et du logo de la canette :
// moitié gauche = côté plat, moitié droite = côté pétillant. On la fait tourner à la souris / au doigt.
// Si WebGL ou le CDN ne répondent pas, l'image 2D de la canette reste affichée (rien ne casse).
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const scene3d = document.querySelector('[data-scene]');
const canvas = document.querySelector('[data-canette-3d]');
const reduireAnimations = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

function webglDisponible() {
  try {
    const c = document.createElement('canvas');
    return Boolean(window.WebGLRenderingContext && (c.getContext('webgl2') || c.getContext('webgl')));
  } catch (e) { return false; }
}

if (scene3d && canvas && webglDisponible()) {
  demarrer().catch((e) => console.warn('Canette 3D indisponible, image 2D conservée.', e));
}

// ---------- Chargement des images ----------
const cacheImages = new Map();
function chargerImage(src) {
  if (!cacheImages.has(src)) {
    cacheImages.set(src, new Promise((ok, ko) => {
      const img = new Image();
      img.onload = () => ok(img);
      img.onerror = ko;
      img.src = src;
    }));
  }
  return cacheImages.get(src);
}

// ---------- Texture de la canette ----------
const TEX_L = 2048;
const TEX_H = 1152;

async function dessinerTexture(duo) {
  const [logo, fruitPlat, fruitPet] = await Promise.all([
    chargerImage('/img/logo-twist.png'),
    chargerImage(`/img/fruits/${duo.plat_fruit}.png`),
    chargerImage(`/img/fruits/${duo.petillant_fruit}.png`)
  ]);
  try { await document.fonts.load('800 40px Outfit'); } catch (e) { /* police de secours */ }

  const c = document.createElement('canvas');
  c.width = TEX_L;
  c.height = TEX_H;
  const ctx = c.getContext('2d');
  ctx.imageSmoothingQuality = 'high';

  // Les deux moitiés
  ctx.fillStyle = duo.plat_couleur;
  ctx.fillRect(0, 0, TEX_L / 2, TEX_H);
  ctx.fillStyle = duo.petillant_couleur;
  ctx.fillRect(TEX_L / 2, 0, TEX_L / 2, TEX_H);

  // Léger dégradé vertical pour donner du volume
  const g = ctx.createLinearGradient(0, 0, 0, TEX_H);
  g.addColorStop(0, 'rgba(255,255,255,0.10)');
  g.addColorStop(0.5, 'rgba(255,255,255,0)');
  g.addColorStop(1, 'rgba(0,0,0,0.10)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, TEX_L, TEX_H);

  // Gouttes / bulles (pseudo-aléatoire stable)
  let graine = 7;
  const alea = () => { graine = (graine * 9301 + 49297) % 233280; return graine / 233280; };
  for (let i = 0; i < 140; i++) {
    const x = alea() * TEX_L;
    const y = alea() * TEX_H;
    const r = 4 + alea() * 14;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,255,255,0.16)';
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'rgba(255,255,255,0.35)';
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(x - r * 0.35, y - r * 0.35, r * 0.28, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,255,255,0.6)';
    ctx.fill();
  }

  // Fruits : côté plat à gauche, côté pétillant à droite
  const fruit = (img, cx, cy, hauteur, rot, miroir) => {
    const l = hauteur * img.width / img.height;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(rot);
    if (miroir) ctx.scale(-1, 1);
    ctx.shadowColor = 'rgba(43,10,20,0.25)';
    ctx.shadowBlur = 18;
    ctx.shadowOffsetY = 8;
    ctx.drawImage(img, -l / 2, -hauteur / 2, l, hauteur);
    ctx.restore();
  };
  const H = TEX_H;
  fruit(fruitPlat, TEX_L * 0.40, H * 0.24, H * 0.30, -0.15, false);
  fruit(fruitPlat, TEX_L * 0.40, H * 0.80, H * 0.30, 0.2, false);
  fruit(fruitPlat, TEX_L * 0.16, H * 0.50, H * 0.34, 0.1, true);
  fruit(fruitPet, TEX_L * 0.60, H * 0.24, H * 0.30, 0.15, true);
  fruit(fruitPet, TEX_L * 0.60, H * 0.80, H * 0.30, -0.2, true);
  fruit(fruitPet, TEX_L * 0.84, H * 0.50, H * 0.34, -0.1, false);

  // Étiquettes, comme sur la canette (STILL / SPARKLING)
  const etiquette = (texte, cx, cy) => {
    const mots = texte.split(' ');
    const lignes = [mots[0], mots.slice(1).join(' ')];
    ctx.fillStyle = '#FFF6EC';
    ctx.font = '800 34px Outfit, system-ui, sans-serif';
    ctx.textAlign = 'center';
    if ('letterSpacing' in ctx) ctx.letterSpacing = '4px';
    lignes.forEach((l, i) => ctx.fillText(l, cx, cy + i * 40));
  };
  etiquette(duo.plat_label, TEX_L * 0.445, H * 0.075);
  etiquette(duo.petillant_label, TEX_L * 0.555, H * 0.075);
  ctx.font = '800 30px Outfit, system-ui, sans-serif';
  ctx.fillText('330 ML', TEX_L * 0.5, H * 0.96);

  // Le logo Twist, centré sur la séparation, avec son ombre portée
  const lLogo = TEX_L * 0.30;
  const hLogo = lLogo * logo.height / logo.width;
  ctx.save();
  ctx.translate(TEX_L * 0.5, H * 0.5);
  ctx.rotate(-0.06);
  ctx.shadowColor = 'rgba(60,10,25,0.55)';
  ctx.shadowOffsetX = 6;
  ctx.shadowOffsetY = 8;
  ctx.shadowBlur = 4;
  ctx.drawImage(logo, -lLogo / 2, -hLogo / 2, lLogo, hLogo);
  ctx.restore();

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

// ---------- Construction de la scène ----------
async function demarrer() {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;

  const scene = new THREE.Scene();
  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;

  const camera = new THREE.PerspectiveCamera(26, 1, 0.1, 100);
  camera.position.set(0, 0.2, 13);

  const lumiere = new THREE.DirectionalLight(0xffffff, 1.4);
  lumiere.position.set(4, 6, 8);
  scene.add(lumiere);
  scene.add(new THREE.AmbientLight(0xffffff, 0.35));

  // Groupe = la canette entière
  const canette = new THREE.Group();
  scene.add(canette);

  const R = 1;
  const HAUTEUR = 3.4;

  // Corps (cylindre ouvert) avec la texture
  const corpsGeo = new THREE.CylinderGeometry(R, R, HAUTEUR, 96, 1, true);
  const corpsMat = new THREE.MeshPhysicalMaterial({ roughness: 0.32, metalness: 0.25, clearcoat: 0.7, clearcoatRoughness: 0.25 });
  const corps = new THREE.Mesh(corpsGeo, corpsMat);
  corps.rotation.y = Math.PI; // la séparation plat | pétillant face à nous
  canette.add(corps);

  // Haut et bas en aluminium (profils tournés)
  const alu = new THREE.MeshStandardMaterial({ color: 0xd8d6dc, metalness: 1, roughness: 0.22 });
  const haut = new THREE.LatheGeometry([
    new THREE.Vector2(R, 0),
    new THREE.Vector2(R * 0.99, 0.08),
    new THREE.Vector2(R * 0.9, 0.24),
    new THREE.Vector2(R * 0.86, 0.32),
    new THREE.Vector2(R * 0.88, 0.36),
    new THREE.Vector2(R * 0.86, 0.39),
    new THREE.Vector2(R * 0.8, 0.36),
    new THREE.Vector2(0, 0.34)
  ], 96);
  const hautMesh = new THREE.Mesh(haut, alu);
  hautMesh.position.y = HAUTEUR / 2;
  canette.add(hautMesh);

  const bas = new THREE.LatheGeometry([
    new THREE.Vector2(0, 0.06),
    new THREE.Vector2(R * 0.6, -0.02),
    new THREE.Vector2(R * 0.82, -0.2),
    new THREE.Vector2(R * 0.9, -0.16),
    new THREE.Vector2(R * 0.99, -0.06),
    new THREE.Vector2(R, 0)
  ], 96);
  const basMesh = new THREE.Mesh(bas, alu);
  basMesh.position.y = -HAUTEUR / 2;
  canette.add(basMesh);

  // La bague « twist » sur le dessus, couleur framboise
  const bague = new THREE.Mesh(
    new THREE.TorusGeometry(R * 0.6, 0.06, 16, 80),
    new THREE.MeshStandardMaterial({ color: 0xc20e2d, metalness: 0.3, roughness: 0.35 })
  );
  bague.rotation.x = Math.PI / 2;
  bague.position.y = HAUTEUR / 2 + 0.38;
  canette.add(bague);
  // Ouverture (languette)
  const languette = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.1, 0.36, 6, 16),
    new THREE.MeshStandardMaterial({ color: 0xbfbcc4, metalness: 1, roughness: 0.3 })
  );
  languette.rotation.z = Math.PI / 2;
  languette.rotation.y = Math.PI / 2;
  languette.position.set(0, HAUTEUR / 2 + 0.4, 0.2);
  canette.add(languette);

  // Ombre douce au sol
  const ombreCanvas = document.createElement('canvas');
  ombreCanvas.width = ombreCanvas.height = 128;
  const octx = ombreCanvas.getContext('2d');
  const og = octx.createRadialGradient(64, 64, 0, 64, 64, 64);
  og.addColorStop(0, 'rgba(43,10,20,0.45)');
  og.addColorStop(1, 'rgba(43,10,20,0)');
  octx.fillStyle = og;
  octx.fillRect(0, 0, 128, 128);
  const ombre = new THREE.Mesh(
    new THREE.PlaneGeometry(3.4, 1.1),
    new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(ombreCanvas), transparent: true, depthWrite: false })
  );
  ombre.rotation.x = -Math.PI / 2;
  ombre.position.y = -HAUTEUR / 2 - 0.55;
  scene.add(ombre);

  canette.rotation.z = -0.08;

  // ---------- Texture selon le duo ----------
  let jetonDuo = 0;
  async function appliquerDuo(duo) {
    const jeton = ++jetonDuo;
    const tex = await dessinerTexture(duo);
    if (jeton !== jetonDuo) { tex.dispose(); return; }
    if (corpsMat.map) corpsMat.map.dispose();
    corpsMat.map = tex;
    corpsMat.needsUpdate = true;
  }

  // ---------- Taille ----------
  function redimensionner() {
    const l = canvas.clientWidth;
    const h = canvas.clientHeight;
    if (!l || !h) return;
    renderer.setSize(l, h, false);
    camera.aspect = l / h;
    camera.updateProjectionMatrix();
  }
  new ResizeObserver(redimensionner).observe(canvas);
  redimensionner();

  // ---------- Interaction : glisser pour tourner ----------
  let angle = 0.35;
  let vitesse = 0;
  let enGlisse = false;
  let dernierX = 0;
  let inclinaison = 0;
  let spin = 0; // rotation bonus quand on change de duo

  canvas.addEventListener('pointerdown', (e) => {
    enGlisse = true;
    dernierX = e.clientX;
    canvas.setPointerCapture(e.pointerId);
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!enGlisse) return;
    const dx = e.clientX - dernierX;
    dernierX = e.clientX;
    vitesse = dx * 0.01;
    angle += vitesse;
  });
  const lacher = () => { enGlisse = false; };
  canvas.addEventListener('pointerup', lacher);
  canvas.addEventListener('pointercancel', lacher);
  window.addEventListener('pointermove', (e) => {
    if (e.pointerType === 'mouse') inclinaison = (e.clientY / window.innerHeight - 0.5) * 0.25;
  }, { passive: true });

  // Clavier : flèches gauche / droite quand le canvas a le focus
  canvas.tabIndex = 0;
  canvas.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowLeft') vitesse -= 0.08;
    if (e.key === 'ArrowRight') vitesse += 0.08;
  });

  // ---------- Changement de duo : la canette fait un « twist » ----------
  window.addEventListener('twist:duo', (e) => {
    const { duo, anime } = e.detail;
    if (anime && !reduireAnimations) {
      spin = Math.PI * 2;
      setTimeout(() => appliquerDuo(duo), 250);
    } else {
      appliquerDuo(duo);
    }
  });

  // Premier duo (déjà choisi par accueil.js, ou on attend l'événement)
  if (window.TwistDuoCourant) await appliquerDuo(window.TwistDuoCourant);

  // ---------- Boucle d'animation (en pause hors de l'écran) ----------
  let visible = true;
  new IntersectionObserver(([entree]) => { visible = entree.isIntersecting; }).observe(scene3d);

  const horloge = new THREE.Clock();
  function boucle() {
    requestAnimationFrame(boucle);
    if (!visible) return;
    const t = horloge.getElapsedTime();

    if (!enGlisse) {
      vitesse *= 0.94;
      const auto = reduireAnimations ? 0 : 0.004;
      angle += vitesse + auto;
    }
    if (spin > 0.001) {
      const pas = spin * 0.08;
      spin -= pas;
      angle += pas;
    }
    canette.rotation.y = angle;
    canette.rotation.x += (inclinaison - canette.rotation.x) * 0.05;
    canette.position.y = reduireAnimations ? 0 : Math.sin(t * 1.4) * 0.12;
    ombre.scale.setScalar(1 - canette.position.y * 0.3);
    bague.rotation.z = -angle * 0.5;
    renderer.render(scene, camera);
  }
  boucle();
  scene3d.classList.add('est-3d');
}
