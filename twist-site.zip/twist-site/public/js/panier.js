// Panier : affiche les articles stockés dans le navigateur, puis enregistre la commande (paiement simulé).
(function () {
  'use strict';
  const { api, euros, echapper, Panier, Auth } = window.Twist;
  const $ = (s) => document.querySelector(s);

  let produits = [];
  let formats = [];
  let livraison = { frais_cents: 390, offerte_des_cents: 2000 };

  document.addEventListener('DOMContentLoaded', async () => {
    try {
      [produits, formats, livraison] = await Promise.all([
        api('/api/products'), api('/api/formats'), api('/api/orders/livraison')
      ]);
    } catch (e) {
      $('[data-lignes]').innerHTML = '<li>Impossible de charger le panier. Le serveur est-il lancé ?</li>';
      return;
    }
    afficher();
    const user = await Auth.pret;
    $('[data-non-connecte]').hidden = Boolean(user);
    $('[data-form-commande]').hidden = !user;
    brancher();
  });

  // Transforme les articles du panier en lignes avec nom, image et prix
  function lignes() {
    return Panier.lire().map((item, index) => {
      const p = produits.find((x) => x.id === item.product_id);
      if (!p) return null;
      if (p.type === 'pack') {
        return { index, p, libelle: '12 canettes · les 8 saveurs', prix: p.prix_cents, quantite: item.quantite };
      }
      const f = formats.find((x) => x.id === item.format_id);
      if (!f) return null;
      return { index, p, libelle: f.label, prix: f.prix_cents, quantite: item.quantite };
    }).filter(Boolean);
  }

  function afficher() {
    const ls = lignes();
    const vide = ls.length === 0;
    $('[data-vide]').hidden = !vide;
    $('[data-resume]').hidden = vide;

    $('[data-lignes]').innerHTML = ls.map((l) => `
      <li class="panier-ligne" style="--a:${l.p.plat_couleur || '#ECA326'};--b:${l.p.petillant_couleur || '#C20E2D'}">
        <div class="panier-visuel"><img src="${l.p.image}" alt="" width="460" height="1368"></div>
        <div class="panier-infos">
          <h2 class="h3-like">${echapper(l.p.nom)}</h2>
          <p>${echapper(l.libelle)} · ${euros(l.prix)}</p>
          <button type="button" class="lien-retirer" data-retirer="${l.index}">Retirer</button>
        </div>
        <div class="quantite quantite-petite">
          <button type="button" data-moins="${l.index}" aria-label="Retirer un ${echapper(l.p.nom)}">−</button>
          <span aria-live="polite">${l.quantite}</span>
          <button type="button" data-plus="${l.index}" aria-label="Ajouter un ${echapper(l.p.nom)}">+</button>
        </div>
        <p class="panier-prix">${euros(l.prix * l.quantite)}</p>
      </li>`).join('');

    const sousTotal = ls.reduce((s, l) => s + l.prix * l.quantite, 0);
    const port = sousTotal >= livraison.offerte_des_cents ? 0 : livraison.frais_cents;
    $('[data-sous-total]').textContent = euros(sousTotal);
    $('[data-port]').textContent = port === 0 ? 'Offerte' : euros(port);
    $('[data-total]').textContent = euros(sousTotal + port);
    $('[data-total-bouton]').textContent = euros(sousTotal + port);
    const manque = livraison.offerte_des_cents - sousTotal;
    $('[data-aide-port]').textContent = manque > 0
      ? `Plus que ${euros(manque)} pour la livraison offerte !`
      : 'Livraison offerte, bien joué.';
  }

  function brancher() {
    $('[data-lignes]').addEventListener('click', (e) => {
      const b = e.target.closest('button');
      if (!b) return;
      const items = Panier.lire();
      if (b.dataset.plus) Panier.changerQuantite(+b.dataset.plus, items[+b.dataset.plus].quantite + 1);
      if (b.dataset.moins) Panier.changerQuantite(+b.dataset.moins, items[+b.dataset.moins].quantite - 1);
      if (b.dataset.retirer) Panier.changerQuantite(+b.dataset.retirer, 0);
      afficher();
    });

    const form = $('[data-form-commande]');
    const msg = $('[data-message]');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      msg.className = 'message-form';
      const bouton = $('[data-payer]');
      bouton.disabled = true;
      try {
        const res = await api('/api/orders', {
          method: 'POST',
          body: { items: Panier.lire(), adresse: form.adresse.value }
        });
        Panier.vider();
        confirmer(res);
      } catch (err) {
        msg.textContent = err.status === 401 ? 'Ta session a expiré, reconnecte-toi.' : err.message;
        msg.classList.add('erreur');
        bouton.disabled = false;
      }
    });
  }

  function confirmer(res) {
    $('[data-vue-panier]').hidden = true;
    const vue = $('[data-vue-confirmation]');
    vue.hidden = false;
    $('[data-conf-prenom]').textContent = Auth.user ? Auth.user.prenom : '';
    $('[data-conf-numero]').textContent = `n° ${res.id}`;
    $('[data-conf-total]').textContent = euros(res.total_cents);
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Pluie de fruits pour fêter ça
    const fruits = ['mangue', 'passion', 'ananas', 'coco', 'litchi', 'framboise', 'pasteque', 'pitaya'];
    const pluie = $('[data-pluie]');
    for (let i = 0; i < 26; i++) {
      const img = document.createElement('img');
      img.src = `/img/fruits/${fruits[i % fruits.length]}.png`;
      img.alt = '';
      img.style.left = `${Math.random() * 100}%`;
      img.style.animationDelay = `${Math.random() * 1.5}s`;
      img.style.animationDuration = `${2.5 + Math.random() * 2}s`;
      img.style.setProperty('--rot', `${(Math.random() - 0.5) * 720}deg`);
      pluie.appendChild(img);
    }
  }
})();
