// Inscription, connexion, page « Mon compte » (historique des commandes) et déconnexion.
(function () {
  'use strict';
  const { api, euros, echapper, Auth } = window.Twist;
  const $ = (s) => document.querySelector(s);

  // Où aller après la connexion ? (?retour=/panier.html) — uniquement un chemin interne
  function retour() {
    const r = new URLSearchParams(location.search).get('retour');
    return r && r.startsWith('/') && !r.startsWith('//') ? r : '/';
  }

  function afficherErreur(msg, texte) {
    msg.textContent = texte;
    msg.className = 'message-form erreur';
  }

  document.addEventListener('DOMContentLoaded', () => {
    // Transmet ?retour= aux liens entre inscription et connexion
    const r = new URLSearchParams(location.search).get('retour');
    if (r) document.querySelectorAll('[data-lien-retour]').forEach((a) => { a.href += `?retour=${encodeURIComponent(r)}`; });

    // Bouton Google affiché seulement s'il est configuré côté serveur
    if (document.querySelector('[data-google]')) {
      api('/api/auth/config').then((c) => { if (c.google) $('[data-google]').hidden = false; }).catch(() => {});
    }
    if (new URLSearchParams(location.search).get('erreur') === 'google') {
      const msg = $('[data-message]');
      if (msg) afficherErreur(msg, 'La connexion avec Google a échoué. Réessaie ou utilise ton email.');
    }

    inscription();
    connexion();
    compte();
  });

  function inscription() {
    const form = $('[data-form-inscription]');
    if (!form) return;
    Auth.pret.then((u) => { if (u) location.replace('/compte.html'); });
    const msg = $('[data-message]');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const prenom = form.prenom.value.trim();
      const email = form.email.value.trim();
      const password = form.password.value;
      if (!prenom || !email || !password) return afficherErreur(msg, 'Remplis tous les champs, s\'il te plaît.');
      if (password.length < 8) return afficherErreur(msg, 'Le mot de passe doit faire au moins 8 caractères.');
      if (password !== form.confirmation.value) return afficherErreur(msg, 'Les deux mots de passe ne sont pas identiques.');
      const bouton = form.querySelector('[type="submit"]');
      bouton.disabled = true;
      try {
        await api('/api/auth/register', { method: 'POST', body: { prenom, email, password } });
        location.href = retour();
      } catch (err) {
        afficherErreur(msg, err.message);
        bouton.disabled = false;
      }
    });
  }

  function connexion() {
    const form = $('[data-form-connexion]');
    if (!form) return;
    Auth.pret.then((u) => { if (u) location.replace(retour() === '/' ? '/compte.html' : retour()); });
    const msg = $('[data-message]');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!form.email.value.trim() || !form.password.value) return afficherErreur(msg, 'Indique ton email et ton mot de passe.');
      const bouton = form.querySelector('[type="submit"]');
      bouton.disabled = true;
      try {
        await api('/api/auth/login', { method: 'POST', body: { email: form.email.value, password: form.password.value } });
        location.href = retour();
      } catch (err) {
        afficherErreur(msg, err.message);
        form.password.value = '';
        bouton.disabled = false;
      }
    });
  }

  async function compte() {
    const zone = $('[data-commandes]');
    if (!zone) return;
    const user = await Auth.pret;
    if (!user) { location.replace('/connexion.html?retour=/compte.html'); return; }

    $('[data-prenom]').textContent = user.prenom;
    $('[data-email]').textContent = user.email;
    $('[data-deconnexion]').addEventListener('click', async () => {
      await api('/api/auth/logout', { method: 'POST' }).catch(() => {});
      location.href = '/';
    });

    try {
      const commandes = await api('/api/orders/mine');
      if (!commandes.length) {
        zone.innerHTML = `<div class="carte vide-compte">
          <p>Aucune commande pour l'instant. Ta première canette t'attend !</p>
          <a class="btn" href="/produit.html">Choisir mon duo</a></div>`;
        return;
      }
      zone.innerHTML = `<ul class="commandes">${commandes.map((c) => `
        <li class="commande carte">
          <div class="commande-tete">
            <p><strong>Commande n° ${c.id}</strong><br><span class="date">${dateFr(c.created_at)}</span></p>
            <span class="badge" data-statut="${echapper(c.statut)}">${echapper(c.statut)}</span>
          </div>
          <ul class="commande-items">${c.items.map((i) => `
            <li><span>${i.quantite} × ${echapper(i.libelle)}</span><span>${euros(i.prix_unitaire_cents * i.quantite)}</span></li>`).join('')}
          </ul>
          <p class="commande-total"><span>Total (livraison comprise)</span><strong>${euros(c.total_cents)}</strong></p>
        </li>`).join('')}</ul>`;
    } catch (e) {
      zone.innerHTML = '<p>Impossible de charger tes commandes.</p>';
    }
  }

  function dateFr(sqlDate) {
    const d = new Date(`${sqlDate.replace(' ', 'T')}Z`);
    return d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
  }
})();
