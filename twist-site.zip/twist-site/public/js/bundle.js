// Landing page du pack : prix lus en base, contenu du pack, un seul appel à l'action (ajouter le pack → panier).
(function () {
  'use strict';
  const { api, euros, echapper, Panier } = window.Twist;
  const $$ = (s) => document.querySelectorAll(s);

  document.addEventListener('DOMContentLoaded', async () => {
    // Le bouton marche même si l'API est lente : il ajoute le pack et file au panier
    $$('[data-cta]').forEach((b) => b.addEventListener('click', () => {
      Panier.ajouter({ product_id: 'pack-decouverte', format_id: null, quantite: 1 });
      location.href = '/panier.html';
    }));

    barreMobile();

    let produits;
    try { produits = await api('/api/products'); } catch (e) { return; }
    const pack = produits.find((p) => p.id === 'pack-decouverte');
    const duos = produits.filter((p) => p.type === 'canette');

    if (pack) {
      const eco = pack.prix_barre_cents - pack.prix_cents;
      const pourcent = Math.round((eco / pack.prix_barre_cents) * 100);
      $$('[data-prix], [data-prix-final], [data-prix-barre-mobile]').forEach((el) => { el.textContent = euros(pack.prix_cents); });
      $$('[data-prix-barre], [data-prix-barre-final]').forEach((el) => { el.textContent = euros(pack.prix_barre_cents); });
      $$('[data-economie]').forEach((el) => { el.textContent = `−${pourcent} %`; });
      $$('.b-sticker span').forEach((el) => { el.textContent = `−${pourcent}%`; });
      $$('[data-eco-chiffre]').forEach((el) => { el.textContent = euros(eco); });
    }

    const zone = document.querySelector('[data-contenu]');
    zone.innerHTML = duos.map((d, i) => `
      <article class="b-duo" data-reveal style="--delai:${i * 0.08}s;--a:${d.plat_couleur};--b:${d.petillant_couleur}">
        <span class="b-fois">×3</span>
        <div class="b-duo-visuel" aria-hidden="true">
          <img src="${d.image}" alt="" loading="lazy" width="460" height="1368">
          <img src="${d.image}" alt="" loading="lazy" width="460" height="1368">
          <img src="${d.image}" alt="" loading="lazy" width="460" height="1368">
        </div>
        <div class="b-duo-infos">
          <h3>${echapper(d.nom)}</h3>
          <p>Plat : ${echapper(d.plat_nom)} · Pétillant : ${echapper(d.petillant_nom)}</p>
        </div>
      </article>`).join('');
    window.Twist.observerApparitions(zone);
  });

  // Sur mobile, la barre d'achat apparaît quand le bouton du hero sort de l'écran
  function barreMobile() {
    const barre = document.querySelector('[data-barre]');
    const ctaHero = document.querySelector('.b-hero [data-cta]');
    const ctaFinal = document.querySelector('.b-final [data-cta]');
    if (!barre || !ctaHero || !('IntersectionObserver' in window)) return;
    const visibles = new Set();
    const obs = new IntersectionObserver((entrees) => {
      entrees.forEach((e) => (e.isIntersecting ? visibles.add(e.target) : visibles.delete(e.target)));
      const montrer = visibles.size === 0 && window.scrollY > 200;
      barre.classList.toggle('est-visible', montrer);
      barre.setAttribute('aria-hidden', String(!montrer));
      barre.querySelector('button').tabIndex = montrer ? 0 : -1;
    });
    obs.observe(ctaHero);
    if (ctaFinal) obs.observe(ctaFinal);
  }
})();
