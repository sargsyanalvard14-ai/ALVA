// Script commun Twist, chargé par toutes les pages :
// header (connexion → « Bonjour Prénom »), menu mobile, panier (localStorage), apparitions au scroll, petits outils.
(function () {
  'use strict';

  // ---------- Outils ----------
  const euros = (cents) => (cents / 100).toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' });

  async function api(url, options = {}) {
    const res = await fetch(url, {
      credentials: 'same-origin',
      headers: options.body ? { 'Content-Type': 'application/json' } : {},
      ...options,
      body: options.body ? JSON.stringify(options.body) : undefined
    });
    let data = null;
    try { data = await res.json(); } catch (e) { data = null; }
    if (!res.ok) {
      const err = new Error((data && data.erreur) || 'Oups, une erreur est survenue.');
      err.status = res.status;
      throw err;
    }
    return data;
  }

  function echapper(texte) {
    const div = document.createElement('div');
    div.textContent = texte == null ? '' : String(texte);
    return div.innerHTML;
  }

  let toastTimer;
  function toast(html) {
    let el = document.querySelector('.toast');
    if (!el) {
      el = document.createElement('div');
      el.className = 'toast';
      el.setAttribute('role', 'status');
      document.body.appendChild(el);
    }
    el.innerHTML = html;
    requestAnimationFrame(() => el.classList.add('est-visible'));
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('est-visible'), 3200);
  }

  // ---------- Panier (stocké dans le navigateur jusqu'à la commande) ----------
  const CLE = 'twist-panier';
  const Panier = {
    lire() {
      try { return JSON.parse(localStorage.getItem(CLE)) || []; } catch (e) { return []; }
    },
    ecrire(items) {
      try { localStorage.setItem(CLE, JSON.stringify(items)); } catch (e) { /* stockage indisponible */ }
      majCompteur(true);
    },
    ajouter({ product_id, format_id = null, quantite = 1 }) {
      const items = Panier.lire();
      const existant = items.find((i) => i.product_id === product_id && i.format_id === format_id);
      if (existant) existant.quantite = Math.min(99, existant.quantite + quantite);
      else items.push({ product_id, format_id, quantite });
      Panier.ecrire(items);
    },
    changerQuantite(index, quantite) {
      const items = Panier.lire();
      if (!items[index]) return;
      if (quantite <= 0) items.splice(index, 1);
      else items[index].quantite = Math.min(99, quantite);
      Panier.ecrire(items);
    },
    vider() { Panier.ecrire([]); },
    nombre() { return Panier.lire().reduce((s, i) => s + i.quantite, 0); }
  };

  function majCompteur(animer) {
    document.querySelectorAll('[data-panier-compte]').forEach((el) => {
      const n = Panier.nombre();
      el.textContent = n;
      el.toggleAttribute('data-vide', n === 0);
      if (animer) { el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop'); }
    });
  }

  // ---------- Header : état de connexion ----------
  const Auth = { user: null, pret: null };
  Auth.pret = api('/api/auth/me')
    .then((d) => { Auth.user = d.user; return d.user; })
    .catch(() => null)
    .then((user) => {
      const bouton = document.querySelector('[data-auth-bouton]');
      if (bouton && user) {
        bouton.textContent = `Bonjour ${user.prenom}`;
        bouton.href = '/compte.html';
        bouton.classList.add('btn-creme');
        if (user.role === 'admin' && !document.querySelector('[data-lien-admin]')) {
          const admin = document.createElement('a');
          admin.href = '/admin/orders.html';
          admin.className = 'btn btn-petit btn-contour';
          admin.textContent = 'Admin';
          admin.setAttribute('data-lien-admin', '');
          bouton.before(admin);
        }
      }
      return user;
    });

  // ---------- Initialisation au chargement ----------
  document.addEventListener('DOMContentLoaded', () => {
    majCompteur(false);

    // Lien actif dans le menu
    const page = document.body.dataset.page;
    document.querySelectorAll('[data-nav]').forEach((a) => {
      if (a.dataset.nav === page) a.setAttribute('aria-current', 'page');
    });

    // Menu mobile
    const toggle = document.querySelector('.menu-toggle');
    const nav = document.getElementById('menu-principal');
    if (toggle && nav) {
      toggle.addEventListener('click', () => {
        const ouvert = toggle.getAttribute('aria-expanded') === 'true';
        toggle.setAttribute('aria-expanded', String(!ouvert));
        nav.classList.toggle('est-ouvert', !ouvert);
      });
      nav.addEventListener('click', (e) => {
        if (e.target.tagName === 'A') { toggle.setAttribute('aria-expanded', 'false'); nav.classList.remove('est-ouvert'); }
      });
    }

    // Header qui prend une bordure au scroll
    const header = document.querySelector('.site-header');
    const surScroll = () => header && header.classList.toggle('est-scrolle', window.scrollY > 10);
    window.addEventListener('scroll', surScroll, { passive: true });
    surScroll();

    observerApparitions();
    genererBulles();
  });

  // Apparitions au scroll (attribut data-reveal)
  let observateur;
  function observerApparitions(racine = document) {
    const els = racine.querySelectorAll('[data-reveal]:not(.est-visible)');
    if (!('IntersectionObserver' in window)) { els.forEach((el) => el.classList.add('est-visible')); return; }
    if (!observateur) {
      observateur = new IntersectionObserver((entrees) => {
        entrees.forEach((e) => {
          if (e.isIntersecting) { e.target.classList.add('est-visible'); observateur.unobserve(e.target); }
        });
      }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });
    }
    els.forEach((el) => observateur.observe(el));
  }

  // Bulles décoratives : <div class="bulles" data-bulles="14"></div>
  function genererBulles() {
    document.querySelectorAll('[data-bulles]').forEach((zone) => {
      if (zone.childElementCount) return;
      const n = Number(zone.dataset.bulles) || 12;
      for (let i = 0; i < n; i++) {
        const b = document.createElement('span');
        b.style.setProperty('--x', `${Math.random() * 100}%`);
        b.style.setProperty('--t', `${8 + Math.random() * 22}px`);
        b.style.setProperty('--d', `${7 + Math.random() * 9}s`);
        b.style.setProperty('--r', `${-Math.random() * 12}s`);
        zone.appendChild(b);
      }
    });
  }

  // Exposé aux scripts des pages
  window.Twist = { api, euros, echapper, toast, Panier, Auth, observerApparitions };
})();
