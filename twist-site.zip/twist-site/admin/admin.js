// Back-office : stats, commandes (changement de statut), utilisateurs, messages.
// Les pages ne sont servies qu'à l'admin, et chaque appel /api/admin est revérifié par le serveur.
(function () {
  'use strict';
  const { api, euros, echapper } = window.Twist;
  const $ = (s) => document.querySelector(s);
  const page = document.body.dataset.admin;

  const dateFr = (d) => new Date(`${d.replace(' ', 'T')}Z`).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' });

  document.addEventListener('DOMContentLoaded', async () => {
    document.querySelectorAll('[data-admin-nav]').forEach((a) => {
      if (a.dataset.adminNav === page) a.setAttribute('aria-current', 'page');
    });
    try {
      await stats();
      if (page === 'orders') await commandes();
      if (page === 'users') await utilisateurs();
      if (page === 'messages') await messages();
    } catch (e) {
      if (e.status === 403) location.href = '/';
      else document.querySelector('.admin-contenu').insertAdjacentHTML('beforeend', `<p class="message-form erreur">${echapper(e.message)}</p>`);
    }
  });

  async function stats() {
    const s = await api('/api/admin/stats');
    const cartes = {
      orders: [[s.commandes, 'commandes'], [s.a_preparer, 'à préparer'], [euros(s.chiffre_cents), 'chiffre d\'affaires (simulé)']],
      users: [[s.utilisateurs, 'clients inscrits'], [s.commandes, 'commandes'], [s.newsletter, 'abonnés newsletter']],
      messages: [[s.messages, 'messages reçus'], [s.newsletter, 'abonnés newsletter']]
    }[page] || [];
    $('[data-stats]').innerHTML = cartes.map(([v, l]) => `<div class="stat"><strong>${echapper(v)}</strong><span>${l}</span></div>`).join('');
  }

  // ---------- Commandes ----------
  async function commandes() {
    const { statuts, commandes: liste } = await api('/api/admin/orders');
    let filtre = 'toutes';

    const filtres = $('[data-filtres]');
    filtres.innerHTML = ['toutes', ...statuts].map((s) => `<button type="button" data-filtre="${s}" aria-pressed="${s === filtre}">${s}</button>`).join('');
    filtres.addEventListener('click', (e) => {
      const b = e.target.closest('[data-filtre]');
      if (!b) return;
      filtre = b.dataset.filtre;
      filtres.querySelectorAll('button').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
      afficher();
    });

    function afficher() {
      const lignes = liste.filter((c) => filtre === 'toutes' || c.statut === filtre);
      $('[data-lignes]').innerHTML = lignes.length ? lignes.map((c) => `
        <tr>
          <td><strong>${c.id}</strong></td>
          <td class="petit">${dateFr(c.created_at)}</td>
          <td>${echapper(c.prenom)}<br><span class="petit">${echapper(c.email)}</span></td>
          <td><ul>${c.items.map((i) => `<li>${i.quantite} × ${echapper(i.libelle)}</li>`).join('')}</ul></td>
          <td><strong>${euros(c.total_cents)}</strong></td>
          <td class="petit">${echapper(c.adresse)}</td>
          <td>
            <label class="visuellement-cache" for="statut-${c.id}">Statut de la commande ${c.id}</label>
            <select id="statut-${c.id}" data-commande="${c.id}">
              ${statuts.map((s) => `<option value="${s}" ${s === c.statut ? 'selected' : ''}>${s}</option>`).join('')}
            </select>
          </td>
        </tr>`).join('') : '<tr><td colspan="7">Aucune commande pour ce filtre.</td></tr>';
    }
    afficher();

    $('[data-lignes]').addEventListener('change', async (e) => {
      const select = e.target.closest('[data-commande]');
      if (!select) return;
      const id = Number(select.dataset.commande);
      try {
        await api(`/api/admin/orders/${id}`, { method: 'PATCH', body: { statut: select.value } });
        liste.find((c) => c.id === id).statut = select.value;
        select.classList.remove('enregistre'); void select.offsetWidth; select.classList.add('enregistre');
        stats();
      } catch (err) {
        window.Twist.toast(echapper(err.message));
      }
    });
  }

  // ---------- Utilisateurs ----------
  async function utilisateurs() {
    const users = await api('/api/admin/users');
    $('[data-lignes]').innerHTML = users.map((u) => `
      <tr>
        <td>${u.id}</td>
        <td><strong>${echapper(u.prenom)}</strong></td>
        <td>${echapper(u.email)}${u.via_google ? ' <span class="badge">Google</span>' : ''}</td>
        <td><span class="badge">${echapper(u.role)}</span></td>
        <td class="petit">${dateFr(u.created_at)}</td>
        <td>${u.nb_commandes}</td>
        <td>${euros(u.total_cents)}</td>
      </tr>`).join('');
  }

  // ---------- Messages ----------
  async function messages() {
    const { messages: liste, newsletter } = await api('/api/admin/messages');
    $('[data-messages]').innerHTML = liste.length ? liste.map((m) => `
      <article class="message-carte">
        <strong>${echapper(m.nom)}</strong> · <a href="mailto:${echapper(m.email)}">${echapper(m.email)}</a>
        <span class="petit"> · ${dateFr(m.created_at)}</span>
        <p>${echapper(m.message)}</p>
      </article>`).join('') : '<p>Aucun message pour l\'instant.</p>';
    $('[data-newsletter]').innerHTML = newsletter.length
      ? `<div class="table-scroll"><table class="admin-table"><thead><tr><th>Email</th><th>Inscrit le</th></tr></thead><tbody>
          ${newsletter.map((n) => `<tr><td>${echapper(n.email)}</td><td class="petit">${dateFr(n.created_at)}</td></tr>`).join('')}
         </tbody></table></div>`
      : '<p>Aucun inscrit pour l\'instant.</p>';
  }
})();
