# Charte graphique — Twist

> Une canette, deux goûts. La charte part de la canette : deux moitiés de couleur, un logo crème en lettres rondes et gonflées, des fruits dessinés, des bulles.

## 1. Ton

**Fun et complice.** On parle comme un·e pote qui a trouvé un bon plan : on tutoie, on fait des phrases courtes et des jeux de mots sur le *twist*, le *deux* et *choisir son camp*. On reste toujours clair sur le prix et sur ce qu'on achète.

| Page | Ligne éditoriale | Exemple |
|---|---|---|
| Accueil | La promesse, en grand. On surprend, on donne envie de tourner la canette. | « Une canette. Deux goûts. » |
| Page produit | Gourmand et précis : un côté plat, un côté pétillant, le prix, le format. | « Côté plat : mangue bien mûre, toute douce. » |
| Pack (bundle) | Malin et rassurant : on économise, on goûte tout, on est livré vite. | « Les 8 saveurs, 12 canettes, zéro dilemme. » |
| Compte client | Simple et chaleureux, sans blabla. | « Content de te revoir, Alva ! » |
| Back-office | Neutre et efficace (usage interne). | « 12 commandes à préparer. » |

Mots de la marque : *twist*, *ton camp*, *plat* / *pétillant* (sur la canette : **STILL** / **SPARKLING**), *duo*, *gorgée*.
Mots à éviter : le jargon technique, les promesses santé non prouvées.

## 2. Couleurs

Toutes les couleurs sont relevées sur les canettes.

| Rôle | Variable | Valeur | Origine |
|---|---|---|---|
| Fond | `--couleur-fond` | `#FFF6EC` | crème du logo, éclaircie |
| Crème (logo) | `--couleur-creme` | `#F1E0D3` | lettres « Twist » |
| Texte | `--couleur-texte` | `#2B0A14` | aubergine très foncée (pépins du fruit de la passion) |
| Accent (boutons) | `--couleur-accent` | `#C20E2D` | framboise pétillante |
| Accent 2 | `--couleur-accent-2` | `#ECA326` | mangue plate |

**Les 4 duos** : chaque produit a sa couleur *plate* (gauche) et sa couleur *pétillante* (droite).

| Duo | Plat | Pétillant |
|---|---|---|
| Mangue × Passion | `#ECA326` | `#DC524C` |
| Ananas × Coco | `#EAB52F` | `#DDC7B2` |
| Litchi × Framboise | `#E9908F` | `#C20E2D` |
| Pastèque × Pitaya | `#F97064` | `#D00B54` |

## 3. Polices (Google Fonts)

- **Titres** : *Shrikhand*. Rond, gonflé, rétro, de la même famille d'esprit que le logo. Uniquement pour les gros titres (h1, h2) : jamais en petit, jamais en paragraphe.
- **Texte** : *Outfit* (400, 600, 800). Une sans-serif géométrique, proche de la police des étiquettes de la canette.
- **Étiquettes** : *Outfit* 800, en MAJUSCULES, espacement de 0,14em, comme « STILL MANGO » sur la canette.

## 4. Règles par élément

- **Logo** : toujours l'image `public/img/logo-twist.png`, jamais retapé dans une police. En crème sur fond coloré, en aubergine sur fond crème (coloré avec un masque CSS).
- **Titres** : Shrikhand, couleur texte ou crème, interligne serré (1). Un mot peut passer en couleur d'accent.
- **Textes** : Outfit 400, 1.05rem, interligne 1.6, 65 caractères max par ligne.
- **Boutons** : pilule (`border-radius: 999px`), **pleins** couleur accent, texte crème, Outfit 800 en majuscules. Au survol, ils se soulèvent et l'ombre durcit (ombre décalée, effet sticker). Bouton secondaire : contour 2px.
- **Liens** : soulignés au survol, couleur accent.
- **Cartes** : coins arrondis 28px, fond séparé en deux couleurs (plat | pétillant) pour les produits.
- **Espacements** : échelle de 8px (`--espace-1` à `--espace-8`). Sections généreuses (96px en haut et en bas).
- **Images** : les vraies canettes et les fruits dessinés de la canette. Pas de photo de stock. Les fruits flottent autour des canettes.
- **Motif** : le **split**, c'est-à-dire un fond coupé en deux moitiés verticales, comme la canette. Des bulles rondes et légères en décor.
- **Animations** : tout bouge un peu, rien ne gêne. Fruits qui flottent, apparitions au scroll, canette 3D qu'on fait tourner. Tout est désactivé si l'utilisateur a demandé « réduire les animations ».

## 5. Référence

[ciaokombucha.com](https://www.ciaokombucha.com) : images produit en grand, une bande défilante de saveurs, des textes courts et sensoriels, une newsletter « Rejoins-nous ».
